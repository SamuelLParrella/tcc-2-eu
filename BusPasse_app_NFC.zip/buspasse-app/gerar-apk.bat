@echo off
chcp 65001 >nul
echo.
echo === BusPasse: gerando o APK do app (Android) ===
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Falta instalar o Node.js ^(versao 20 ou mais nova^): https://nodejs.org
  echo Instale, feche esta janela e de dois cliques neste arquivo de novo.
  pause
  exit /b 1
)

:: Esta pasta nao e um repositorio git: pede ao EAS para nao exigir git.
set EAS_NO_VCS=1

echo [1/3] Instalando as dependencias ^(demora alguns minutos na primeira vez^)...
call npm install
if errorlevel 1 goto erro

echo.
echo [2/3] Login no Expo ^(conta gratuita: https://expo.dev/signup^)...
call npx --yes eas-cli@latest whoami >nul 2>nul
if errorlevel 1 (
  call npx --yes eas-cli@latest login
  if errorlevel 1 goto erro
)

echo.
echo [3/3] Gerando o APK na nuvem do Expo ^(10 a 30 minutos^).
echo Se perguntar se deve criar o projeto ou gerar um Keystore, responda Y.
call npx --yes eas-cli@latest build --platform android --profile preview
if errorlevel 1 goto erro

echo.
echo Pronto! Abra o link do build no celular Android, baixe o APK e instale.
pause
exit /b 0

:erro
echo.
echo Algo deu errado. Copie a mensagem de erro acima e mande para mim.
pause
exit /b 1
