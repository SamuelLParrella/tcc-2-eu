import { StyleSheet } from "react-native";

// Estilos compartilhados que dependem do tema — chame dentro do componente
// com getSharedStyles(colors), usando o `colors` de useTheme().
export function getSharedStyles(C) {
  return StyleSheet.create({
    screen: {
      flex: 1,
      backgroundColor: C.offWhite,
    },

    label: {
      fontSize: 13,
      fontWeight: "700",
      color: C.headingSoft,
      marginBottom: 4,
    },
    input: {
      width: "100%",
      paddingVertical: 12,
      paddingHorizontal: 14,
      borderRadius: 12,
      borderWidth: 1.5,
      borderColor: C.border,
      fontSize: 15,
      color: C.text,
      backgroundColor: C.surface,
    },
    inputFocused: {
      borderColor: C.lightGreen,
    },

    btnGreen: {
      width: "100%",
      paddingVertical: 15,
      borderRadius: 50,
      backgroundColor: C.lightGreen,
      alignItems: "center",
      justifyContent: "center",
    },
    btnOrange: {
      width: "100%",
      paddingVertical: 15,
      borderRadius: 50,
      backgroundColor: C.amber,
      alignItems: "center",
      justifyContent: "center",
    },
    btnRed: {
      width: "100%",
      paddingVertical: 15,
      borderRadius: 50,
      backgroundColor: C.red,
      alignItems: "center",
      justifyContent: "center",
    },
    btnOutline: {
      width: "100%",
      paddingVertical: 14,
      borderRadius: 50,
      backgroundColor: "transparent",
      borderWidth: 2,
      borderColor: C.green,
      alignItems: "center",
      justifyContent: "center",
    },
    btnTextWhite: {
      color: C.onColor,
      fontWeight: "800",
      fontSize: 16,
      letterSpacing: 0.3,
    },
    btnTextGreen: {
      color: C.headingSoft,
      fontWeight: "800",
      fontSize: 16,
    },

    card: {
      backgroundColor: C.surface,
      borderRadius: 16,
      padding: 20,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.06,
      shadowRadius: 12,
      elevation: 2,
    },

    errorBox: {
      marginHorizontal: 28,
      marginBottom: 12,
      padding: 12,
      borderRadius: 10,
      backgroundColor: C.errorBg,
      borderWidth: 1,
      borderColor: C.errorBorder,
    },
    errorText: {
      fontSize: 13,
      color: C.errorText,
      fontWeight: "600",
    },
    okBox: {
      marginBottom: 12,
      padding: 12,
      borderRadius: 10,
      backgroundColor: C.okBg,
      borderWidth: 1,
      borderColor: C.okBorder,
    },
    okText: {
      fontSize: 13,
      color: C.okText,
      fontWeight: "600",
    },
  });
}
