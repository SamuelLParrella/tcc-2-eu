// Paleta clara (padrão) e escura do app. Cores de marca (darkGreen, green,
// lightGreen, brightGreen, amber, orange, red) permanecem praticamente
// constantes entre os temas — elas já são usadas como fundo de elementos
// coloridos (cabeçalhos, botões, badges). "surface"/"offWhite"/"text" etc.
// são as que realmente invertem entre claro e escuro.

export const LIGHT = {
  darkGreen: "#1E4D2B",
  green: "#2D7A3A",
  lightGreen: "#4CAF50",
  brightGreen: "#6DD96D",
  orange: "#E07B00",
  amber: "#F5A623",
  red: "#E53935",

  onColor: "#FFFFFF",   // texto/ícone fixo sobre fundo colorido (não muda com o tema)
  surface: "#FFFFFF",   // fundo de cartões, inputs, modais
  offWhite: "#F7F9F5",  // fundo da tela
  lightGray: "#E8EDE8", // superfície secundária (avatar, trilho de toggle/tabs)
  gray: "#8A8A8A",
  border: "#D4DDD4",
  text: "#1A1A1A",
  textMuted: "#6B7B6B",

  // Verde usado como cor de TEXTO (títulos/labels) sobre a superfície da tela
  headingStrong: "#1E4D2B",
  headingSoft: "#2D7A3A",

  errorBg: "#FEE2E2",
  errorBorder: "#FCA5A5",
  errorText: "#B91C1C",
  okBg: "#D1FAE5",
  okBorder: "#6EE7B7",
  okText: "#065F46",
};

export const DARK = {
  darkGreen: "#1E4D2B",
  green: "#2D7A3A",
  lightGreen: "#4CAF50",
  brightGreen: "#6DD96D",
  orange: "#FF9C33",
  amber: "#F7B955",
  red: "#FF6B67",

  onColor: "#FFFFFF",
  surface: "#1C2620",
  offWhite: "#10140F",
  lightGray: "#232B26",
  gray: "#9BA39B",
  border: "#2E3A32",
  text: "#ECEFEC",
  textMuted: "#9AA79A",

  headingStrong: "#7FE0A0",
  headingSoft: "#6FCF87",

  errorBg: "#3A1B1B",
  errorBorder: "#6B2E2E",
  errorText: "#FF8A80",
  okBg: "#173226",
  okBorder: "#2E5C42",
  okText: "#7FE0AE",
};

// Mantido para qualquer uso que ainda não tenha migrado para useTheme() —
// sempre reflete a paleta clara.
export const C = LIGHT;
