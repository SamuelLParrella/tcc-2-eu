import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { useTheme } from "../theme/ThemeContext";

const TABS = [
  { key: "saldo", label: "Saldo", icon: "◉" },
  { key: "recarga", label: "Recarga", icon: "↑" },
  { key: "conta", label: "Conta", icon: "👤" },
];

export default function BottomNav({ active, navigate }) {
  const { colors: C } = useTheme();
  const styles = StyleSheet.create({
    wrap: {
      flexDirection: "row",
      backgroundColor: C.darkGreen,
      paddingTop: 10,
      paddingBottom: 6,
    },
    tab: {
      flex: 1,
      alignItems: "center",
      gap: 2,
    },
  });

  return (
    <View style={styles.wrap}>
      {TABS.map((t) => {
        const isActive = active === t.key;
        return (
          <TouchableOpacity key={t.key} onPress={() => navigate(t.key)} style={styles.tab}>
            <Text style={{ fontSize: isActive ? 22 : 18, color: isActive ? C.brightGreen : "rgba(255,255,255,0.55)" }}>
              {t.icon}
            </Text>
            <Text
              style={{
                fontSize: 11,
                fontWeight: isActive ? "800" : "600",
                color: isActive ? C.brightGreen : "rgba(255,255,255,0.55)",
              }}
            >
              {t.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}
