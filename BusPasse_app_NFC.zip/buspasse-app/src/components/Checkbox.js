import { TouchableOpacity, Text, StyleSheet } from "react-native";
import { useTheme } from "../theme/ThemeContext";

export default function Checkbox({ checked, onToggle }) {
  const { colors: C } = useTheme();
  const styles = StyleSheet.create({
    box: {
      width: 20,
      height: 20,
      borderRadius: 5,
      borderWidth: 1.5,
      borderColor: C.border,
      backgroundColor: C.surface,
      alignItems: "center",
      justifyContent: "center",
    },
    boxChecked: {
      backgroundColor: C.lightGreen,
      borderColor: C.lightGreen,
    },
    check: {
      color: C.onColor,
      fontSize: 13,
      fontWeight: "900",
    },
  });

  return (
    <TouchableOpacity onPress={onToggle} style={[styles.box, checked && styles.boxChecked]} hitSlop={6}>
      {checked && <Text style={styles.check}>✓</Text>}
    </TouchableOpacity>
  );
}
