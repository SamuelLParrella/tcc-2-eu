import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { useTheme } from "../theme/ThemeContext";

export default function TopBar({ title, onBack }) {
  const { colors: C } = useTheme();
  const styles = StyleSheet.create({
    wrap: {
      flexDirection: "row",
      alignItems: "center",
      paddingTop: 18,
      paddingBottom: 14,
      paddingHorizontal: 20,
      backgroundColor: C.surface,
      borderBottomWidth: 1,
      borderBottomColor: C.border,
    },
    backBtn: { marginRight: 12 },
    backText: { fontSize: 22, color: C.headingStrong, fontWeight: "900" },
    title: { fontWeight: "800", fontSize: 17, color: C.headingStrong },
  });

  return (
    <View style={styles.wrap}>
      {onBack && (
        <TouchableOpacity onPress={onBack} hitSlop={10} style={styles.backBtn}>
          <Text style={styles.backText}>←</Text>
        </TouchableOpacity>
      )}
      <Text style={styles.title}>{title}</Text>
    </View>
  );
}
