import { Modal, View, Text, TouchableOpacity, StyleSheet, Pressable } from "react-native";
import { useTheme } from "../theme/ThemeContext";

export default function AppModal({ visible, children, onClose, color }) {
  const { colors: C } = useTheme();
  const bg = color || C.surface;
  const isDefaultSurface = bg === C.surface;

  return (
    <Modal visible={!!visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={styles.overlay} onPress={onClose}>
        <Pressable style={[styles.box, { backgroundColor: bg }]} onPress={(e) => e.stopPropagation?.()}>
          {onClose && (
            <TouchableOpacity onPress={onClose} style={styles.closeBtn} hitSlop={10}>
              <Text style={[styles.closeText, { color: isDefaultSurface ? C.text : C.onColor }]}>✕</Text>
            </TouchableOpacity>
          )}
          {children}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  box: {
    borderRadius: 20,
    padding: 28,
    width: "100%",
    maxWidth: 340,
  },
  closeBtn: {
    position: "absolute",
    top: 12,
    right: 16,
    zIndex: 1,
  },
  closeText: {
    fontSize: 20,
    fontWeight: "800",
  },
});
