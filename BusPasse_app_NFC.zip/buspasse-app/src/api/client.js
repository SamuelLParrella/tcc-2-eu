import AsyncStorage from "@react-native-async-storage/async-storage";

// API em produção no Render
export const API_URL = "https://tcc-82gl.onrender.com";

const TOKEN_KEY = "buspass_token";

export function getToken() {
  return AsyncStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  return AsyncStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  return AsyncStorage.removeItem(TOKEN_KEY);
}

// Wrapper de fetch: injeta o token salvo, serializa o corpo em JSON e
// transforma respostas de erro (res.detail) em Error com mensagem amigável.
export async function apiFetch(path, { method = "GET", body, token, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };

  let authToken = token;
  if (auth && !authToken) authToken = await getToken();
  if (auth && authToken) headers.Authorization = `Bearer ${authToken}`;

  const res = await fetch(`${API_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try {
    data = await res.json();
  } catch (e) {
    // resposta sem corpo (ex.: erro de rede antes de chegar no servidor)
  }

  if (!res.ok) {
    const err = new Error(data?.detail || "Não foi possível se comunicar com o servidor.");
    err.status = res.status;
    throw err;
  }
  return data;
}
