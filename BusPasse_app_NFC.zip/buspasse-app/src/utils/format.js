const MESES = [
  "jan.", "fev.", "mar.", "abr.", "mai.", "jun.",
  "jul.", "ago.", "set.", "out.", "nov.", "dez.",
];

export function formatMoney(valor) {
  return `R$ ${Number(valor).toFixed(2).replace(".", ",")}`;
}

export function formatDateTime(isoString) {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return "";
  const dia = d.getDate();
  const mes = MESES[d.getMonth()];
  const hh = d.getHours();
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${dia} de ${mes} - ${hh}:${mm}`;
}

export function formatDateLong(isoString) {
  const DIAS = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return "";
  const dia = String(d.getDate()).padStart(2, "0");
  const mes = String(d.getMonth() + 1).padStart(2, "0");
  const ano = d.getFullYear();
  return `${DIAS[d.getDay()]}, ${dia}/${mes}/${ano}`;
}

export function formatTime(isoString) {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return "";
  return `${d.getHours()}:${String(d.getMinutes()).padStart(2, "0")}`;
}
