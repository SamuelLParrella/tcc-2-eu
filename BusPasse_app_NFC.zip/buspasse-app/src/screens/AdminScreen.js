import { useCallback, useEffect, useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, ActivityIndicator, RefreshControl, StyleSheet } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import TopBar from "../components/TopBar";

export default function AdminScreen({ navigate }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    subtitle: { fontSize: 13, color: C.textMuted, marginBottom: 20 },
    itemCard: { ...s.card, marginBottom: 14 },
    nome: { fontWeight: "800", fontSize: 15, color: C.headingStrong, marginBottom: 2 },
    email: { fontSize: 12, color: C.textMuted, marginBottom: 10 },
    escolaLabel: { fontSize: 12, fontWeight: "700", color: C.headingSoft, marginBottom: 2 },
    escolaValor: { fontSize: 13, color: C.text, marginBottom: 12 },
    actions: { flexDirection: "row", gap: 10 },
    btnHalf: { flex: 1 },
  });

  const [solicitacoes, setSolicitacoes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [erro, setErro] = useState("");
  const [processando, setProcessando] = useState(null); // id da solicitação em ação

  const carregar = useCallback(async () => {
    setErro("");
    try {
      const data = await apiFetch("/admin/solicitacoes-estudante");
      setSolicitacoes(data);
    } catch (e) {
      setErro(e.message);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    carregar().finally(() => setLoading(false));
  }, [carregar]);

  const onRefresh = async () => {
    setRefreshing(true);
    await carregar();
    setRefreshing(false);
  };

  const resolver = async (id, aprovar) => {
    setProcessando(id);
    try {
      await apiFetch(`/admin/solicitacoes-estudante/${id}`, { method: "POST", body: { aprovar } });
      setSolicitacoes((lista) => lista.filter((item) => item.id !== id));
    } catch (e) {
      setErro(e.message);
    } finally {
      setProcessando(null);
    }
  };

  return (
    <View style={s.screen}>
      <TopBar title="Painel de aprovações" onBack={() => navigate("conta")} />
      <ScrollView
        contentContainerStyle={{ padding: 24 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <Text style={styles.subtitle}>Solicitações de tarifa de estudante aguardando confirmação da escola.</Text>

        {erro ? (
          <View style={s.errorBox}>
            <Text style={s.errorText}>{erro}</Text>
          </View>
        ) : null}

        {loading ? (
          <ActivityIndicator size="large" color={C.lightGreen} style={{ marginTop: 32 }} />
        ) : solicitacoes.length === 0 ? (
          <Text style={{ color: C.textMuted, fontSize: 13 }}>Nenhuma solicitação pendente.</Text>
        ) : (
          solicitacoes.map((item) => (
            <View key={item.id} style={styles.itemCard}>
              <Text style={styles.nome}>{item.nome}</Text>
              <Text style={styles.email}>{item.email}</Text>
              <Text style={styles.escolaLabel}>Escola informada</Text>
              <Text style={styles.escolaValor}>{item.escola_nome} — {item.escola_email}</Text>
              <View style={styles.actions}>
                <TouchableOpacity
                  style={[s.btnGreen, styles.btnHalf, { opacity: processando === item.id ? 0.7 : 1 }]}
                  onPress={() => resolver(item.id, true)}
                  disabled={processando === item.id}
                >
                  <Text style={s.btnTextWhite}>Aprovar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[s.btnRed, styles.btnHalf, { opacity: processando === item.id ? 0.7 : 1 }]}
                  onPress={() => resolver(item.id, false)}
                  disabled={processando === item.id}
                >
                  <Text style={s.btnTextWhite}>Recusar</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}
