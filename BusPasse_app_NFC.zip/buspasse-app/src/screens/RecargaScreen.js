import { useEffect, useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, Alert } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import BottomNav from "../components/BottomNav";
import { formatMoney } from "../utils/format";

const VALORES_RAPIDOS = [10, 20, 50, 100];

export default function RecargaScreen({ navigate, setRecargaValor }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    header: { backgroundColor: C.darkGreen, paddingTop: 22, paddingBottom: 18, paddingHorizontal: 20 },
    headerTitle: { color: C.lightGreen, fontWeight: "900", fontSize: 22, textAlign: "center" },
    content: { padding: 24 },
    sectionTitle: { fontWeight: "800", fontSize: 15, color: C.headingStrong, marginBottom: 14 },
    grid: { flexDirection: "row", flexWrap: "wrap", gap: 12, marginBottom: 22 },
    valorBtn: { width: "47%", paddingVertical: 18, borderRadius: 14, borderWidth: 2, alignItems: "center" },
    valorBtnText: { color: C.lightGreen, fontWeight: "800", fontSize: 17 },
    customBox: { backgroundColor: C.darkGreen, borderRadius: 14, paddingVertical: 14, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 24 },
    customPrefix: { color: C.lightGreen, fontWeight: "800", fontSize: 16 },
    customInput: { color: C.lightGreen, fontSize: 16, fontWeight: "700", flex: 1, padding: 0 },
    blockedBanner: { backgroundColor: C.red, borderRadius: 12, padding: 14, marginBottom: 20 },
    blockedBannerText: { color: C.onColor, fontWeight: "800", fontSize: 13, textAlign: "center" },
  });

  const [selected, setSelected] = useState(null);
  const [custom, setCustom] = useState("");
  const [bloqueado, setBloqueado] = useState(false);

  useEffect(() => {
    apiFetch("/me")
      .then((data) => setBloqueado(!!data.cartao_bloqueado))
      .catch(() => {});
  }, []);

  const parseCustom = () => {
    const numero = parseFloat(custom.replace(",", "."));
    return Number.isFinite(numero) ? numero : 0;
  };

  const handleGerar = () => {
    if (bloqueado) {
      Alert.alert("Cartão bloqueado", "Desbloqueie o cartão em Conta → Status do cartão para fazer recarga.");
      return;
    }
    const valor = selected ?? parseCustom();
    if (!valor || valor <= 0) {
      Alert.alert("Valor inválido", "Escolha um valor rápido ou digite um valor válido para recarregar.");
      return;
    }
    if (valor > 500) {
      Alert.alert("Valor muito alto", "O valor máximo de recarga é R$ 500,00.");
      return;
    }
    setRecargaValor(valor);
    navigate("qrcode");
  };

  return (
    <View style={s.screen}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Recarga</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        {bloqueado && (
          <View style={styles.blockedBanner}>
            <Text style={styles.blockedBannerText}>
              🔒 Seu cartão está bloqueado. Desbloqueie em Conta → Status do cartão para fazer recarga.
            </Text>
          </View>
        )}
        <Text style={styles.sectionTitle}>Valor rápido</Text>
        <View style={styles.grid}>
          {VALORES_RAPIDOS.map((v) => {
            const isSelected = selected === v;
            return (
              <TouchableOpacity
                key={v}
                onPress={() => { setSelected(v); setCustom(""); }}
                style={[
                  styles.valorBtn,
                  { backgroundColor: isSelected ? C.lightGreen : C.darkGreen, borderColor: isSelected ? C.brightGreen : C.lightGreen },
                ]}
              >
                <Text style={styles.valorBtnText}>{formatMoney(v)}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <Text style={styles.sectionTitle}>Outro valor</Text>
        <View style={styles.customBox}>
          <Text style={styles.customPrefix}>R$</Text>
          <TextInput
            value={custom}
            onChangeText={(v) => { setCustom(v); setSelected(null); }}
            placeholder="0,00"
            placeholderTextColor="rgba(109,217,109,0.6)"
            keyboardType="decimal-pad"
            style={styles.customInput}
          />
        </View>

        <TouchableOpacity style={s.btnGreen} onPress={handleGerar}>
          <Text style={s.btnTextWhite}>Gerar QR Code</Text>
        </TouchableOpacity>
      </ScrollView>
      <BottomNav active="recarga" navigate={navigate} />
    </View>
  );
}
