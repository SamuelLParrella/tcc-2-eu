import { useCallback, useEffect, useRef, useState } from "react";
import { View, Text, TouchableOpacity, ScrollView, ActivityIndicator, StyleSheet } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import TopBar from "../components/TopBar";
import { formatMoney } from "../utils/format";
import {
  nfcDisponivelNoApp,
  celularSuportaHce,
  nfcLigado,
  armarToken,
  desarmarToken,
  abrirConfiguracoesNfc,
} from "../nfc/hce";

const TEXTO_MOTIVO = {
  cartao_bloqueado: "Cartão bloqueado. Desbloqueie em Conta → Status do cartão para usar o passe.",
  saldo_insuficiente: "Saldo insuficiente para a passagem. Faça uma recarga e tente de novo.",
  token_expirado: "O código venceu antes de chegar ao leitor. Ative de novo e aproxime logo em seguida.",
};

function formatarContagem(segundos) {
  const m = Math.floor(segundos / 60);
  const s = String(segundos % 60).padStart(2, "0");
  return `${m}:${s}`;
}

export default function NfcScreen({ navigate }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    content: { padding: 24 },
    center: { alignItems: "center" },
    titulo: { fontWeight: "900", fontSize: 18, color: C.headingStrong, marginBottom: 8 },
    texto: { fontSize: 14, color: C.text, lineHeight: 20 },
    textoMuted: { fontSize: 13, color: C.textMuted, lineHeight: 19 },
    linhaInfo: { flexDirection: "row", justifyContent: "space-between", marginBottom: 6 },
    infoLabel: { fontSize: 13, color: C.textMuted },
    infoValor: { fontSize: 14, fontWeight: "800", color: C.headingStrong },
    passo: { fontSize: 13, color: C.text, marginBottom: 4 },
    caixa: { borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1 },
    caixaAviso: { backgroundColor: C.errorBg, borderColor: C.errorBorder },
    caixaAvisoTexto: { fontSize: 13, fontWeight: "600", color: C.errorText },
    caixaOk: { backgroundColor: C.okBg, borderColor: C.okBorder },
    caixaOkTexto: { fontSize: 13, fontWeight: "600", color: C.okText },
    circulo: {
      width: 150, height: 150, borderRadius: 75, borderWidth: 4, borderColor: C.lightGreen,
      alignItems: "center", justifyContent: "center", marginTop: 8, marginBottom: 18,
    },
    contagem: { fontSize: 28, fontWeight: "900", color: C.headingStrong },
    grande: { fontWeight: "900", fontSize: 20, color: C.headingStrong, textAlign: "center", marginBottom: 6 },
    espaco: { height: 12 },
  });

  // carregando | indisponivel | pronto | ativando | ativo | sucesso | negado | expirado | erro
  const [fase, setFase] = useState("carregando");
  const [motivoIndisponivel, setMotivoIndisponivel] = useState("");
  const [me, setMe] = useState(null);
  const [nfcDesligado, setNfcDesligado] = useState(false);
  const [segundos, setSegundos] = useState(0);
  const [mensagem, setMensagem] = useState("");
  const [motivoNegado, setMotivoNegado] = useState("");
  const [saldoFinal, setSaldoFinal] = useState(null);

  const expiraEmRef = useRef(0);
  const armadoRef = useRef(false);     // existe um token armado no celular/servidor?
  const consultandoRef = useRef(false); // evita duas consultas ao /nfc/status ao mesmo tempo
  const montadoRef = useRef(true);

  // Carrega o estado inicial e, ao sair da tela, desarma qualquer token que tenha sobrado.
  useEffect(() => {
    montadoRef.current = true;
    (async () => {
      if (!nfcDisponivelNoApp) {
        setMotivoIndisponivel("app");
        setFase("indisponivel");
        return;
      }
      if (!(await celularSuportaHce())) {
        setMotivoIndisponivel("hce");
        setFase("indisponivel");
        return;
      }
      try {
        const dados = await apiFetch("/me");
        const ligado = await nfcLigado();
        if (!montadoRef.current) return;
        setMe(dados);
        setNfcDesligado(!ligado);
        setFase("pronto");
      } catch (e) {
        if (!montadoRef.current) return;
        setMensagem(e.message);
        setFase("erro");
      }
    })();

    return () => {
      montadoRef.current = false;
      if (armadoRef.current) {
        armadoRef.current = false;
        desarmarToken();
        apiFetch("/nfc/cancelar", { method: "POST" }).catch(() => {});
      }
    };
  }, []);

  const encerrar = useCallback((novaFase, motivo = "") => {
    armadoRef.current = false;
    desarmarToken();
    if (novaFase === "expirado") {
      apiFetch("/nfc/cancelar", { method: "POST" }).catch(() => {});
    }
    setMotivoNegado(motivo);
    setFase(novaFase);
  }, []);

  const concluirComSucesso = useCallback(async () => {
    armadoRef.current = false;
    desarmarToken();
    try {
      const dados = await apiFetch("/me");
      if (montadoRef.current) setSaldoFinal(dados);
    } catch (e) {
      // sem o saldo novo a tela de sucesso ainda funciona
    }
    if (montadoRef.current) setFase("sucesso");
  }, []);

  // Enquanto o token está ativo: contagem regressiva a cada 1 s e, a cada 2 s,
  // pergunta à API se o leitor já validou (ou recusou) a passagem.
  useEffect(() => {
    if (fase !== "ativo") return undefined;
    let tick = 0;
    const id = setInterval(async () => {
      tick += 1;
      const restante = Math.max(0, Math.ceil((expiraEmRef.current - Date.now()) / 1000));
      setSegundos(restante);
      if (restante === 0) {
        encerrar("expirado");
        return;
      }
      if (tick % 2 !== 0 || consultandoRef.current) return;
      consultandoRef.current = true;
      try {
        const st = await apiFetch("/nfc/status");
        if (!montadoRef.current || !armadoRef.current) return;
        if (st.resultado === "ok") {
          await concluirComSucesso();
        } else if (st.resultado) {
          encerrar("negado", st.resultado);
        }
      } catch (e) {
        // falha de rede momentânea: tenta de novo no próximo ciclo
      } finally {
        consultandoRef.current = false;
      }
    }, 1000);
    return () => clearInterval(id);
  }, [fase, encerrar, concluirComSucesso]);

  const ativar = async () => {
    setMensagem("");
    setMotivoNegado("");
    setFase("ativando");
    try {
      if (!(await nfcLigado())) {
        setNfcDesligado(true);
        setFase("pronto");
        return;
      }
      setNfcDesligado(false);
      const r = await apiFetch("/nfc/token", { method: "POST" });
      await armarToken(r.token, r.validade_segundos);
      armadoRef.current = true;
      expiraEmRef.current = Date.now() + r.validade_segundos * 1000;
      setSegundos(r.validade_segundos);
      setFase("ativo");
    } catch (e) {
      setMensagem(e.message);
      if (e.status === 423) {
        setMotivoNegado("cartao_bloqueado");
        setFase("negado");
      } else if (e.status === 422) {
        setMotivoNegado("saldo_insuficiente");
        setFase("negado");
      } else {
        setFase("erro");
      }
    }
  };

  const cancelar = async () => {
    armadoRef.current = false;
    await desarmarToken();
    apiFetch("/nfc/cancelar", { method: "POST" }).catch(() => {});
    setFase("pronto");
  };

  const voltarAoSaldo = () => navigate("saldo");

  const bloqueado = !!me?.cartao_bloqueado;
  const tarifaTexto = me ? (me.tarifa_atual === 0 ? "Gratuita" : formatMoney(me.tarifa_atual)) : "—";

  const renderConteudo = () => {
    if (fase === "carregando") {
      return <ActivityIndicator size="large" color={C.lightGreen} style={{ marginTop: 40 }} />;
    }

    if (fase === "indisponivel") {
      return (
        <View style={s.card}>
          <Text style={styles.titulo}>NFC indisponível</Text>
          <Text style={styles.texto}>
            {motivoIndisponivel === "hce"
              ? "Este celular não suporta pagamento por aproximação (emulação de cartão NFC)."
              : "O pagamento por aproximação só funciona no aplicativo BusPasse instalado (APK) em um celular Android com NFC. No Expo Go e no Snack este recurso fica desativado."}
          </Text>
        </View>
      );
    }

    if (fase === "pronto" || fase === "ativando") {
      return (
        <>
          <View style={s.card}>
            <Text style={styles.titulo}>Use o celular como cartão</Text>
            <View style={styles.linhaInfo}>
              <Text style={styles.infoLabel}>Valor da passagem</Text>
              <Text style={styles.infoValor}>{tarifaTexto}</Text>
            </View>
            <View style={[styles.linhaInfo, { marginBottom: 14 }]}>
              <Text style={styles.infoLabel}>Saldo disponível</Text>
              <Text style={styles.infoValor}>{me ? formatMoney(me.saldo) : "—"}</Text>
            </View>
            <Text style={styles.passo}>1. Toque em “Ativar” aqui embaixo.</Text>
            <Text style={styles.passo}>2. Deixe a tela ligada e desbloqueada.</Text>
            <Text style={styles.passo}>3. Encoste a parte de trás do celular no leitor do ônibus.</Text>
          </View>

          <View style={styles.espaco} />

          {bloqueado && (
            <View style={[styles.caixa, styles.caixaAviso]}>
              <Text style={styles.caixaAvisoTexto}>{TEXTO_MOTIVO.cartao_bloqueado}</Text>
            </View>
          )}

          {nfcDesligado && (
            <View style={[styles.caixa, styles.caixaAviso]}>
              <Text style={styles.caixaAvisoTexto}>
                O NFC está desligado neste celular. Ligue-o nas configurações para pagar por aproximação.
              </Text>
              <TouchableOpacity style={{ marginTop: 10 }} onPress={abrirConfiguracoesNfc}>
                <Text style={[styles.caixaAvisoTexto, { textDecorationLine: "underline" }]}>
                  Abrir configurações de NFC
                </Text>
              </TouchableOpacity>
            </View>
          )}

          <TouchableOpacity
            style={[s.btnGreen, { opacity: bloqueado || fase === "ativando" ? 0.5 : 1 }]}
            onPress={ativar}
            disabled={bloqueado || fase === "ativando"}
          >
            <Text style={s.btnTextWhite}>{fase === "ativando" ? "Ativando..." : "Ativar pagamento por aproximação"}</Text>
          </TouchableOpacity>
        </>
      );
    }

    if (fase === "ativo") {
      return (
        <View style={styles.center}>
          <View style={styles.circulo}>
            <Text style={{ fontSize: 56 }}>📲</Text>
          </View>
          <Text style={styles.grande}>Aproxime o celular do leitor</Text>
          <Text style={[styles.textoMuted, { textAlign: "center", marginBottom: 16 }]}>
            Encoste a parte de trás do celular no leitor do ônibus e mantenha parado por um instante.
          </Text>
          <Text style={styles.contagem}>{formatarContagem(segundos)}</Text>
          <Text style={[styles.textoMuted, { marginBottom: 24 }]}>tempo restante deste código</Text>
          <TouchableOpacity style={s.btnOutline} onPress={cancelar}>
            <Text style={s.btnTextGreen}>Cancelar</Text>
          </TouchableOpacity>
        </View>
      );
    }

    if (fase === "sucesso") {
      return (
        <View style={styles.center}>
          <View style={[styles.circulo, { borderColor: C.lightGreen, backgroundColor: C.okBg }]}>
            <Text style={{ fontSize: 64, color: C.okText, fontWeight: "900" }}>✓</Text>
          </View>
          <Text style={styles.grande}>Passagem validada!</Text>
          {saldoFinal && (
            <Text style={[styles.textoMuted, { textAlign: "center", marginBottom: 24 }]}>
              Saldo atual: {formatMoney(saldoFinal.saldo)}
            </Text>
          )}
          <TouchableOpacity style={s.btnGreen} onPress={voltarAoSaldo}>
            <Text style={s.btnTextWhite}>Voltar ao saldo</Text>
          </TouchableOpacity>
        </View>
      );
    }

    if (fase === "negado") {
      return (
        <>
          <View style={[styles.caixa, styles.caixaAviso]}>
            <Text style={styles.caixaAvisoTexto}>{TEXTO_MOTIVO[motivoNegado] || mensagem || "Passagem não autorizada."}</Text>
          </View>
          {motivoNegado === "saldo_insuficiente" ? (
            <TouchableOpacity style={s.btnGreen} onPress={() => navigate("recarga")}>
              <Text style={s.btnTextWhite}>Fazer uma recarga</Text>
            </TouchableOpacity>
          ) : motivoNegado === "cartao_bloqueado" ? (
            <TouchableOpacity style={s.btnGreen} onPress={() => navigate("statusCartao")}>
              <Text style={s.btnTextWhite}>Ver status do cartão</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={s.btnGreen} onPress={ativar}>
              <Text style={s.btnTextWhite}>Tentar de novo</Text>
            </TouchableOpacity>
          )}
          <View style={styles.espaco} />
          <TouchableOpacity style={s.btnOutline} onPress={voltarAoSaldo}>
            <Text style={s.btnTextGreen}>Voltar ao saldo</Text>
          </TouchableOpacity>
        </>
      );
    }

    if (fase === "expirado") {
      return (
        <>
          <View style={[styles.caixa, styles.caixaAviso]}>
            <Text style={styles.caixaAvisoTexto}>O tempo acabou e o código foi desativado. Ative de novo quando estiver perto do leitor.</Text>
          </View>
          <TouchableOpacity style={s.btnGreen} onPress={ativar}>
            <Text style={s.btnTextWhite}>Ativar de novo</Text>
          </TouchableOpacity>
          <View style={styles.espaco} />
          <TouchableOpacity style={s.btnOutline} onPress={voltarAoSaldo}>
            <Text style={s.btnTextGreen}>Voltar ao saldo</Text>
          </TouchableOpacity>
        </>
      );
    }

    // erro
    return (
      <>
        <View style={[styles.caixa, styles.caixaAviso]}>
          <Text style={styles.caixaAvisoTexto}>{mensagem || "Não foi possível ativar o pagamento por aproximação."}</Text>
        </View>
        <TouchableOpacity style={s.btnGreen} onPress={ativar}>
          <Text style={s.btnTextWhite}>Tentar de novo</Text>
        </TouchableOpacity>
        <View style={styles.espaco} />
        <TouchableOpacity style={s.btnOutline} onPress={voltarAoSaldo}>
          <Text style={s.btnTextGreen}>Voltar ao saldo</Text>
        </TouchableOpacity>
      </>
    );
  };

  return (
    <View style={s.screen}>
      <TopBar title="Pagar com o celular" onBack={voltarAoSaldo} />
      <ScrollView contentContainerStyle={styles.content}>{renderConteudo()}</ScrollView>
    </View>
  );
}
