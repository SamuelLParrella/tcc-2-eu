import { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, ScrollView, Modal, Pressable, StyleSheet } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import BottomNav from "../components/BottomNav";

const TIPO_LABEL = { comum: "Comum", estudante: "Estudante", pcd: "PCD", idoso: "Idoso" };

const MENU_ITEMS = [
  { label: "Tipo de Usuário", nav: "tipoUsuario" },
  { label: "Status do cartão", nav: "statusCartao" },
  { label: "Alterar senha", nav: "alterarSenha" },
  { label: "Alterar informações", nav: "alterarInfo" },
];

export default function ContaScreen({ navigate, user, onLogout }) {
  const { colors: C, isDark, toggleTheme } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    profile: { paddingTop: 28, paddingBottom: 20, paddingHorizontal: 24, flexDirection: "row", alignItems: "center", gap: 16 },
    avatar: { width: 60, height: 60, borderRadius: 30, backgroundColor: C.lightGray, alignItems: "center", justifyContent: "center" },
    nome: { color: C.amber, fontWeight: "900", fontSize: 18 },
    tipo: { fontSize: 13, color: C.textMuted, fontWeight: "600" },
    divider: { height: 1, backgroundColor: C.green, opacity: 0.3 },
    menuRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 18, paddingHorizontal: 24 },
    menuLabel: { fontWeight: "700", fontSize: 15, color: C.text },
    chevron: { color: C.headingStrong, fontWeight: "900", fontSize: 18 },
    toggleTrack: { width: 44, height: 24, borderRadius: 50, padding: 2, justifyContent: "center" },
    toggleThumb: { width: 20, height: 20, borderRadius: 10, backgroundColor: C.onColor },
    sheetOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.3)", justifyContent: "flex-end" },
    sheet: { backgroundColor: "rgba(220,220,220,0.97)", borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20, paddingBottom: 90 },
    sheetHandle: { width: 36, height: 4, backgroundColor: C.gray, borderRadius: 2, alignSelf: "center", marginBottom: 16 },
    sheetCard: { backgroundColor: C.surface, borderRadius: 16, overflow: "hidden", borderWidth: 1.5, borderColor: C.border },
    accountRow: { flexDirection: "row", alignItems: "center", padding: 16, gap: 12 },
    accountRowBorder: { borderBottomWidth: 1, borderBottomColor: C.border },
    accountName: { fontWeight: "700", flex: 1, color: C.text },
    checkBadge: { width: 24, height: 24, borderRadius: 12, backgroundColor: C.lightGreen, alignItems: "center", justifyContent: "center" },
    addBadge: { width: 28, height: 28, borderRadius: 14, backgroundColor: C.darkGreen, alignItems: "center", justifyContent: "center" },
  });

  const [showAccounts, setShowAccounts] = useState(false);
  const [tipoUsuario, setTipoUsuario] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    apiFetch("/me")
      .then((data) => {
        if (data.tipo_usuario) setTipoUsuario(TIPO_LABEL[data.tipo_usuario] || data.tipo_usuario);
        setIsAdmin(!!data.admin);
      })
      .catch(() => {});
  }, []);

  const menuItems = isAdmin
    ? [...MENU_ITEMS, { label: "Painel de aprovações", nav: "admin" }]
    : MENU_ITEMS;

  return (
    <View style={s.screen}>
      <ScrollView style={{ flex: 1 }}>
        <View style={styles.profile}>
          <View style={styles.avatar}>
            <Text style={{ fontSize: 28 }}>👤</Text>
          </View>
          <View>
            <Text style={styles.nome}>{user?.nome || "Usuário"}</Text>
            <Text style={styles.tipo}>{tipoUsuario || "Comum"}</Text>
          </View>
        </View>

        {menuItems.map((item) => (
          <View key={item.label}>
            <View style={styles.divider} />
            <TouchableOpacity style={styles.menuRow} onPress={() => navigate(item.nav)}>
              <Text style={styles.menuLabel}>{item.label}</Text>
              <Text style={styles.chevron}>›</Text>
            </TouchableOpacity>
          </View>
        ))}

        <View style={styles.divider} />
        <TouchableOpacity style={styles.menuRow} onPress={toggleTheme}>
          <Text style={styles.menuLabel}>Aparência {isDark ? "(escura)" : "(clara)"}</Text>
          <View style={[styles.toggleTrack, { backgroundColor: C.amber }]}>
            <View style={[styles.toggleThumb, { alignSelf: isDark ? "flex-end" : "flex-start" }]} />
          </View>
        </TouchableOpacity>

        <View style={styles.divider} />
        <TouchableOpacity style={styles.menuRow} onPress={() => setShowAccounts(true)}>
          <Text style={styles.menuLabel}>Acessar outra conta</Text>
          <Text style={styles.chevron}>∨</Text>
        </TouchableOpacity>

        <View style={styles.divider} />
        <TouchableOpacity style={styles.menuRow} onPress={onLogout}>
          <Text style={styles.menuLabel}>Sair da conta</Text>
          <Text style={styles.chevron}>›</Text>
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={showAccounts} transparent animationType="slide" onRequestClose={() => setShowAccounts(false)}>
        <Pressable style={styles.sheetOverlay} onPress={() => setShowAccounts(false)}>
          <Pressable style={styles.sheet} onPress={(e) => e.stopPropagation?.()}>
            <View style={styles.sheetHandle} />
            <View style={styles.sheetCard}>
              <View style={[styles.accountRow, styles.accountRowBorder]}>
                <Text style={{ fontSize: 22, color: C.lightGreen }}>👤</Text>
                <Text style={styles.accountName}>{user?.nome || "Usuário"}</Text>
                <View style={styles.checkBadge}>
                  <Text style={{ color: C.onColor, fontSize: 14, fontWeight: "900" }}>✓</Text>
                </View>
              </View>
              <View style={[styles.accountRow, { opacity: 0.5 }]}>
                <View style={styles.addBadge}>
                  <Text style={{ color: C.onColor, fontWeight: "900", fontSize: 18 }}>+</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.accountName}>Adicionar conta</Text>
                  <Text style={{ fontSize: 11, color: C.textMuted }}>Em breve</Text>
                </View>
              </View>
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      <BottomNav active="conta" navigate={navigate} />
    </View>
  );
}
