import { useCallback, useEffect, useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, RefreshControl, StyleSheet, Alert, Platform } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import BottomNav from "../components/BottomNav";
import { formatMoney, formatDateTime } from "../utils/format";

const TIPO_LABEL = {
  comum: "Comum",
  estudante: "Estudante",
  pcd: "PCD",
  idoso: "Idoso",
};

export default function SaldoScreen({ navigate, setSelectedTx, user }) {
  const { colors: C } = useTheme();
  const styles = StyleSheet.create({
    screen: { flex: 1, backgroundColor: C.offWhite },
    header: { backgroundColor: C.darkGreen, paddingTop: 28, paddingBottom: 22, paddingHorizontal: 22 },
    headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
    nome: { color: C.amber, fontWeight: "900", fontSize: 20 },
    badge: { backgroundColor: C.lightGreen, borderRadius: 50, paddingVertical: 2, paddingHorizontal: 10, marginTop: 4, alignSelf: "flex-start" },
    badgeText: { color: C.onColor, fontSize: 11, fontWeight: "700" },
    recargaBtn: { backgroundColor: C.onColor, borderWidth: 2, borderColor: C.lightGreen, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 12 },
    recargaBtnText: { fontSize: 12, fontWeight: "700", color: C.darkGreen, textAlign: "center" },
    recargaBtnLink: { fontSize: 12, fontWeight: "700", color: C.lightGreen, textAlign: "center" },
    loadingText: { color: "rgba(255,255,255,0.6)", fontSize: 13, marginTop: 18, textAlign: "center" },
    erroText: { color: C.amber, fontSize: 12, marginTop: 14, textAlign: "center" },
    statsRow: { flexDirection: "row", marginTop: 18 },
    statBox: { flex: 1, alignItems: "center", paddingHorizontal: 8 },
    statBoxBorder: { borderRightWidth: 1, borderRightColor: "rgba(255,255,255,0.2)" },
    statLabel: { color: "rgba(255,255,255,0.7)", fontSize: 11, marginBottom: 4 },
    statValue: { color: C.onColor, fontWeight: "900", fontSize: 26 },
    nfcBtn: { marginTop: 16, alignSelf: "center", paddingVertical: 10, paddingHorizontal: 20, borderRadius: 50, backgroundColor: C.amber },
    nfcBtnDisabled: { opacity: 0.4 },
    nfcBtnText: { color: C.darkGreen, fontSize: 13, fontWeight: "800" },
    usarPasseBtn: { marginTop: 16, alignSelf: "center", paddingVertical: 6, paddingHorizontal: 14, borderRadius: 50, borderWidth: 1, borderColor: "rgba(255,255,255,0.35)" },
    usarPasseBtnDisabled: { opacity: 0.4, borderColor: "rgba(255,255,255,0.15)" },
    usarPasseText: { color: "rgba(255,255,255,0.8)", fontSize: 11, fontWeight: "700" },
    blockedBanner: { backgroundColor: C.red, borderRadius: 12, padding: 14, marginTop: 16 },
    blockedBannerText: { color: C.onColor, fontWeight: "800", fontSize: 13, textAlign: "center" },
    extratoWrap: { flex: 1 },
    extratoTitle: { fontWeight: "800", fontSize: 17, color: C.headingStrong, marginBottom: 14 },
    txRow: { flexDirection: "row", alignItems: "center", gap: 14, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: C.border, marginBottom: 14 },
    txIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center" },
    txIconDebit: { backgroundColor: C.darkGreen },
    txIconCredit: { borderWidth: 2, borderColor: C.lightGreen },
    txLabel: { fontWeight: "700", fontSize: 15, color: C.text },
    txDate: { fontSize: 12, color: C.textMuted },
    txValue: { fontWeight: "800", fontSize: 15 },
  });

  const [meData, setMeData] = useState(null);
  const [transacoes, setTransacoes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [erro, setErro] = useState("");
  const [usandoPasse, setUsandoPasse] = useState(false);

  const carregar = useCallback(async () => {
    setErro("");
    try {
      const [me, extrato] = await Promise.all([
        apiFetch("/me"),
        apiFetch("/extrato"),
      ]);
      setMeData(me);
      setTransacoes(extrato);
    } catch (e) {
      setErro(e.message);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    carregar().finally(() => setLoading(false));
  }, [carregar]);

  const onRefresh = async () => {
    setRefreshing(true);
    await carregar();
    setRefreshing(false);
  };

  const usarPassagem = async () => {
    setUsandoPasse(true);
    try {
      await apiFetch("/passagem/usar", { method: "POST" });
      await carregar();
    } catch (e) {
      Alert.alert("Não foi possível usar o passe", e.message);
    } finally {
      setUsandoPasse(false);
    }
  };

  const bloqueado = !!meData?.cartao_bloqueado;
  const nomeExibido = meData?.nome ?? user?.nome ?? "Usuário";
  const tipoExibido = TIPO_LABEL[meData?.tipo_usuario] ?? "Comum";
  const saldoExibido = meData ? formatMoney(meData.saldo) : "—";
  const passesExibidos = !meData ? "—" : meData.passes_disponiveis === null ? "Ilimitado" : meData.passes_disponiveis.toFixed(1);

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.nome}>{nomeExibido}</Text>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{tipoExibido}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.recargaBtn} onPress={() => navigate("recarga")}>
            <Text style={styles.recargaBtnText}>Quer recarregar?</Text>
            <Text style={styles.recargaBtnLink}>→ Clique aqui!</Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <Text style={styles.loadingText}>Carregando saldo...</Text>
        ) : erro ? (
          <Text style={styles.erroText}>⚠ Não foi possível carregar o saldo.</Text>
        ) : (
          <View style={styles.statsRow}>
            <View style={[styles.statBox, styles.statBoxBorder]}>
              <Text style={styles.statLabel}>Passes disponíveis</Text>
              <Text style={styles.statValue}>{passesExibidos}</Text>
            </View>
            <View style={styles.statBox}>
              <Text style={styles.statLabel}>Saldo disponível</Text>
              <Text style={styles.statValue}>{saldoExibido}</Text>
            </View>
          </View>
        )}

        {bloqueado && (
          <View style={styles.blockedBanner}>
            <Text style={styles.blockedBannerText}>
              🔒 Seu cartão está bloqueado. Desbloqueie em Conta → Status do cartão para usar o passe.
            </Text>
          </View>
        )}

        {Platform.OS === "android" && (
          <TouchableOpacity
            style={[styles.nfcBtn, bloqueado && styles.nfcBtnDisabled]}
            onPress={() => navigate("nfc")}
            disabled={bloqueado}
          >
            <Text style={styles.nfcBtnText}>📲 Pagar com o celular (NFC)</Text>
          </TouchableOpacity>
        )}

        <TouchableOpacity
          style={[styles.usarPasseBtn, (usandoPasse || bloqueado) && styles.usarPasseBtnDisabled]}
          onPress={usarPassagem}
          disabled={usandoPasse || bloqueado}
        >
          <Text style={styles.usarPasseText}>
            {usandoPasse ? "Validando..." : bloqueado ? "Passe indisponível (cartão bloqueado)" : "Simular uso do passe (demo)"}
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.extratoWrap}
        contentContainerStyle={{ padding: 20 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <Text style={styles.extratoTitle}>Extrato</Text>
        {!loading && transacoes.length === 0 ? (
          <Text style={{ color: C.textMuted, fontSize: 13 }}>Nenhuma transação ainda.</Text>
        ) : (
          transacoes.map((tx) => {
            const isDebit = tx.tipo === "debito";
            return (
              <TouchableOpacity
                key={tx.id}
                style={styles.txRow}
                onPress={() => { setSelectedTx(tx); navigate("txDetail"); }}
              >
                <View style={[styles.txIcon, isDebit ? styles.txIconDebit : styles.txIconCredit]}>
                  <Text style={{ fontSize: 20, fontWeight: "900", color: isDebit ? C.amber : C.lightGreen }}>
                    {isDebit ? "↓" : "↑"}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.txLabel}>{tx.descricao}</Text>
                  <Text style={styles.txDate}>{formatDateTime(tx.data)}</Text>
                </View>
                <Text style={[styles.txValue, { color: isDebit ? C.amber : C.headingStrong }]}>
                  {isDebit ? "-" : "+"}
                  {formatMoney(tx.valor)}
                </Text>
              </TouchableOpacity>
            );
          })
        )}
      </ScrollView>
      <BottomNav active="saldo" navigate={navigate} />
    </View>
  );
}
