import { useEffect, useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ScrollView, ActivityIndicator, StyleSheet } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import TopBar from "../components/TopBar";

const CAMPOS = [
  { label: "Nome", key: "nome", placeholder: "João Silva" },
  { label: "Email", key: "email", placeholder: "joao@email.com", keyboardType: "email-address" },
  { label: "Celular", key: "celular", placeholder: "(00) 00000-0000", keyboardType: "phone-pad" },
  { label: "CEP", key: "cep", placeholder: "00000-000" },
  { label: "Cidade", key: "cidade", placeholder: "São Paulo" },
  { label: "Bairro", key: "bairro", placeholder: "Liberdade" },
  { label: "Rua", key: "rua", placeholder: "R. João Silva" },
  { label: "Número", key: "numero", placeholder: "000" },
  { label: "Complemento", key: "complemento", placeholder: "Apto 42" },
];

const CAMPO_VAZIO = { nome: "", email: "", celular: "", cep: "", cidade: "", bairro: "", rua: "", numero: "", complemento: "" };

export default function AlterarInfoScreen({ navigate, onPerfilAtualizado }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    title: { fontWeight: "800", fontSize: 17, color: C.headingSoft, marginBottom: 20 },
    readOnlyInput: { backgroundColor: C.lightGray, color: C.textMuted },
    legenda: { fontSize: 12, color: C.amber, marginTop: -6 },
  });

  const [form, setForm] = useState(CAMPO_VAZIO);
  const [cpf, setCpf] = useState("");
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  const [msg, setMsg] = useState({ tipo: "", texto: "" });

  useEffect(() => {
    apiFetch("/me")
      .then((data) => {
        setCpf(data.cpf || "");
        setForm({
          nome: data.nome || "", email: data.email || "", celular: data.celular || "",
          cep: data.cep || "", cidade: data.cidade || "", bairro: data.bairro || "",
          rua: data.rua || "", numero: data.numero || "", complemento: data.complemento || "",
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const setField = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const handleConfirmar = async () => {
    setMsg({ tipo: "", texto: "" });
    setSalvando(true);
    try {
      const atualizado = await apiFetch("/me", { method: "PUT", body: form });
      onPerfilAtualizado?.(atualizado);
      setMsg({ tipo: "ok", texto: "Informações salvas com sucesso!" });
    } catch (e) {
      setMsg({ tipo: "err", texto: e.message });
    } finally {
      setSalvando(false);
    }
  };

  return (
    <View style={s.screen}>
      <TopBar title="Alterar informações" onBack={() => navigate("conta")} />
      <ScrollView contentContainerStyle={{ padding: 24 }}>
        <Text style={styles.title}>Altere suas informações</Text>

        {loading ? (
          <ActivityIndicator size="large" color={C.lightGreen} style={{ marginTop: 32 }} />
        ) : (
          <View style={{ gap: 14 }}>
            <View>
              <Text style={[s.label, { color: C.amber }]}>CPF*</Text>
              <TextInput style={[s.input, styles.readOnlyInput]} value={cpf} editable={false} />
            </View>

            {CAMPOS.map((f) => (
              <View key={f.key}>
                <Text style={s.label}>{f.label}</Text>
                <TextInput
                  style={s.input}
                  placeholder={f.placeholder}
                  placeholderTextColor={C.textMuted}
                  keyboardType={f.keyboardType}
                  value={form[f.key]}
                  onChangeText={(v) => setField(f.key, v)}
                />
              </View>
            ))}

            <Text style={styles.legenda}>* Informações inalteráveis.</Text>

            {msg.texto ? (
              <View style={msg.tipo === "ok" ? s.okBox : s.errorBox}>
                <Text style={msg.tipo === "ok" ? s.okText : s.errorText}>{msg.texto}</Text>
              </View>
            ) : null}

            <TouchableOpacity style={[s.btnOrange, { opacity: salvando ? 0.7 : 1 }]} onPress={handleConfirmar} disabled={salvando}>
              <Text style={s.btnTextWhite}>{salvando ? "Salvando..." : "Confirmar"}</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
