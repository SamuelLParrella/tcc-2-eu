import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Alert,
} from "react-native";
import { apiFetch, setToken } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import Checkbox from "../components/Checkbox";

const CADASTRO_STEP1_FIELDS = [
  { label: "CPF", placeholder: "000.000.000-00", key: "cpf" },
  { label: "Nome", placeholder: "Seu nome", key: "nome" },
  { label: "Email", placeholder: "seu@email.com", key: "email", keyboardType: "email-address" },
  { label: "Confirmar email", placeholder: "seu@email.com", key: "emailConfirm", keyboardType: "email-address" },
  { label: "Senha", placeholder: "••••••••", key: "senha", secure: true },
];

const CADASTRO_STEP2_FIELDS = [
  { label: "Confirmar senha", placeholder: "••••••••", key: "senhaConfirm", secure: true },
  { label: "Celular", placeholder: "(00) 00000-0000", key: "celular", keyboardType: "phone-pad" },
  { label: "CEP", placeholder: "00000-000", key: "cep" },
  { label: "Cidade", placeholder: "São Paulo", key: "cidade" },
  { label: "Bairro", placeholder: "Liberdade", key: "bairro" },
  { label: "Rua", placeholder: "R. João Silva", key: "rua" },
  { label: "Número", placeholder: "000", key: "numero" },
  { label: "Complemento", placeholder: "Apto 42", key: "complemento" },
];

function Field({ label, value, onChangeText, ...rest }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  return (
    <View>
      <Text style={s.label}>{label}</Text>
      <TextInput
        style={s.input}
        value={value}
        onChangeText={onChangeText}
        placeholderTextColor={C.textMuted}
        autoCapitalize="none"
        {...rest}
      />
    </View>
  );
}

export default function AuthScreen({ onLogin }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    logoArea: { alignItems: "center", paddingTop: 48, paddingBottom: 24, paddingHorizontal: 32 },
    logoBox: {
      width: 90, height: 90, backgroundColor: C.lightGreen, borderRadius: 22,
      marginBottom: 16, alignItems: "center", justifyContent: "center",
      shadowColor: C.lightGreen, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.35, shadowRadius: 18, elevation: 4,
    },
    brand: { fontSize: 26, fontWeight: "900", color: C.orange },
    subtitle: { fontSize: 14, color: C.textMuted, marginTop: 4 },
    tabsWrap: { paddingHorizontal: 28, paddingBottom: 20 },
    tabsBg: { flexDirection: "row", backgroundColor: C.lightGray, borderRadius: 50, padding: 4 },
    tabBtn: { flex: 1, paddingVertical: 10, borderRadius: 50, alignItems: "center" },
    tabText: { fontWeight: "800", fontSize: 15 },
    formArea: { flex: 1, paddingHorizontal: 28 },
    agreeRow: { flexDirection: "row", alignItems: "center", gap: 10 },
    agreeText: { fontSize: 13, color: C.text, flex: 1, flexWrap: "wrap" },
  });

  const [tab, setTab] = useState("entrar");
  const [step, setStep] = useState(1); // 1 | 2 | "verificar"
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [loginEmail, setLoginEmail] = useState("");
  const [loginSenha, setLoginSenha] = useState("");

  const [pendingEmail, setPendingEmail] = useState("");
  const [codigo, setCodigo] = useState("");
  const [reenviando, setReenviando] = useState(false);

  const [form, setForm] = useState({
    cpf: "", nome: "", email: "", emailConfirm: "", senha: "",
    senhaConfirm: "", celular: "", cep: "", cidade: "",
    bairro: "", rua: "", numero: "", complemento: "",
  });
  const setField = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const handleLogin = async () => {
    setError("");
    if (!loginEmail || !loginSenha) {
      setError("Preencha email e senha.");
      return;
    }
    setLoading(true);
    try {
      const data = await apiFetch("/login", {
        method: "POST",
        auth: false,
        body: { email: loginEmail, senha: loginSenha },
      });
      await setToken(data.token);
      onLogin({ nome: data.nome, id: data.id, token: data.token });
    } catch (e) {
      if (e.status === 403) {
        setPendingEmail(loginEmail);
        setStep("verificar");
      } else {
        setError(e.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCadastrar = async () => {
    setError("");

    if (step === 1) {
      if (!form.cpf || !form.nome || !form.email || !form.senha) {
        setError("Preencha todos os campos obrigatórios.");
        return;
      }
      if (form.email !== form.emailConfirm) {
        setError("Os emails não coincidem.");
        return;
      }
      if (form.senha.length < 6) {
        setError("Senha deve ter pelo menos 6 caracteres.");
        return;
      }
      setStep(2);
      return;
    }

    if (form.senha !== form.senhaConfirm) {
      setError("As senhas não coincidem.");
      return;
    }
    if (!agreed) {
      setError("Aceite os Termos de Uso para continuar.");
      return;
    }
    setLoading(true);
    try {
      const data = await apiFetch("/cadastro", {
        method: "POST",
        auth: false,
        body: {
          cpf: form.cpf,
          nome: form.nome,
          email: form.email,
          senha: form.senha,
          celular: form.celular || null,
          cep: form.cep || null,
          cidade: form.cidade || null,
          bairro: form.bairro || null,
          rua: form.rua || null,
          numero: form.numero || null,
          complemento: form.complemento || null,
        },
      });
      setPendingEmail(data.email);
      setStep("verificar");
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerificar = async () => {
    setError("");
    if (codigo.trim().length !== 6) {
      setError("Digite o código de 6 dígitos que enviamos por email.");
      return;
    }
    setLoading(true);
    try {
      const data = await apiFetch("/verificar-email", {
        method: "POST",
        auth: false,
        body: { email: pendingEmail, codigo: codigo.trim() },
      });
      await setToken(data.token);
      onLogin({ nome: data.nome, id: data.id, token: data.token });
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleReenviar = async () => {
    setError("");
    setReenviando(true);
    try {
      await apiFetch("/reenviar-codigo", { method: "POST", auth: false, body: { email: pendingEmail } });
      Alert.alert("Código reenviado", "Confira sua caixa de entrada (e o spam).");
    } catch (e) {
      setError(e.message);
    } finally {
      setReenviando(false);
    }
  };

  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={styles.logoArea}>
        <View style={styles.logoBox}>
          <Text style={{ fontSize: 46 }}>🚌</Text>
        </View>
        <Text style={styles.brand}>
          Seu <Text style={{ color: C.headingStrong }}>Ônibus</Text>
        </Text>
        <Text style={styles.subtitle}>Seu passe digital</Text>
      </View>

      <View style={styles.tabsWrap}>
        <View style={styles.tabsBg}>
          {["entrar", "cadastrar"].map((t) => (
            <TouchableOpacity
              key={t}
              onPress={() => { setTab(t); setStep(1); setError(""); }}
              style={[styles.tabBtn, tab === t && { backgroundColor: C.lightGreen }]}
            >
              <Text style={[styles.tabText, { color: tab === t ? C.onColor : C.headingStrong }]}>
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {error ? (
        <View style={s.errorBox}>
          <Text style={s.errorText}>{error}</Text>
        </View>
      ) : null}

      <ScrollView style={styles.formArea} contentContainerStyle={{ paddingBottom: 24 }} keyboardShouldPersistTaps="handled">
        {step === "verificar" ? (
          <View style={{ gap: 14 }}>
            <Text style={s.label}>
              Enviamos um código de 6 dígitos para{"\n"}
              <Text style={{ fontWeight: "800", color: C.headingStrong }}>{pendingEmail}</Text>
            </Text>
            <Field
              label="Código de confirmação"
              placeholder="000000"
              keyboardType="number-pad"
              maxLength={6}
              value={codigo}
              onChangeText={setCodigo}
            />
            <TouchableOpacity
              style={[s.btnGreen, { marginTop: 8, opacity: loading ? 0.7 : 1 }]}
              onPress={handleVerificar}
              disabled={loading}
            >
              <Text style={s.btnTextWhite}>{loading ? "Confirmando..." : "Confirmar"}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleReenviar} disabled={reenviando}>
              <Text style={{ textAlign: "center", color: C.lightGreen, fontWeight: "700" }}>
                {reenviando ? "Reenviando..." : "Reenviar código"}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => { setStep(1); setTab("entrar"); setError(""); }}>
              <Text style={{ textAlign: "center", color: C.textMuted, fontWeight: "600" }}>Voltar</Text>
            </TouchableOpacity>
          </View>
        ) : tab === "entrar" ? (
          <View style={{ gap: 16 }}>
            <Field
              label="Email"
              placeholder="seu@email.com"
              keyboardType="email-address"
              value={loginEmail}
              onChangeText={setLoginEmail}
            />
            <Field
              label="Senha"
              placeholder="••••••••"
              secureTextEntry
              value={loginSenha}
              onChangeText={setLoginSenha}
              onSubmitEditing={handleLogin}
            />
            <TouchableOpacity style={[s.btnGreen, { marginTop: 8, opacity: loading ? 0.7 : 1 }]} onPress={handleLogin} disabled={loading}>
              <Text style={s.btnTextWhite}>{loading ? "Entrando..." : "Entrar"}</Text>
            </TouchableOpacity>
          </View>
        ) : step === 1 ? (
          <View style={{ gap: 14 }}>
            {CADASTRO_STEP1_FIELDS.map((f) => (
              <Field
                key={f.key}
                label={f.label}
                placeholder={f.placeholder}
                keyboardType={f.keyboardType}
                secureTextEntry={f.secure}
                value={form[f.key]}
                onChangeText={(v) => setField(f.key, v)}
              />
            ))}
            <TouchableOpacity style={[s.btnGreen, { marginTop: 8 }]} onPress={handleCadastrar}>
              <Text style={s.btnTextWhite}>Próximo</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={{ gap: 14 }}>
            {CADASTRO_STEP2_FIELDS.map((f) => (
              <Field
                key={f.key}
                label={f.label}
                placeholder={f.placeholder}
                keyboardType={f.keyboardType}
                secureTextEntry={f.secure}
                value={form[f.key]}
                onChangeText={(v) => setField(f.key, v)}
              />
            ))}
            <TouchableOpacity style={styles.agreeRow} onPress={() => setAgreed(!agreed)}>
              <Checkbox checked={agreed} onToggle={() => setAgreed(!agreed)} />
              <Text style={styles.agreeText}>
                Li e concordo com os <Text style={{ color: C.lightGreen, fontWeight: "700" }}>Termos de Uso</Text>
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[s.btnGreen, { marginTop: 8, opacity: loading ? 0.7 : 1 }]}
              onPress={handleCadastrar}
              disabled={loading}
            >
              <Text style={s.btnTextWhite}>{loading ? "Criando conta..." : "Cadastrar"}</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
