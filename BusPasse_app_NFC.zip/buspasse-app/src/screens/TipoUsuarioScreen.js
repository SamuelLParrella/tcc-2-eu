import { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, TextInput, StyleSheet } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import TopBar from "../components/TopBar";
import AppModal from "../components/AppModal";

const TIPOS = ["Comum", "Estudante", "PCD", "Idoso"];

// PCD e Idoso seguem o mesmo fluxo (enviar → validar → confirmar), então os
// textos ficam centralizados aqui em vez de duplicar os mesmos modais duas
// vezes. Estudante tem um fluxo próprio (ver mais abaixo), porque em vez de
// só simular um upload, manda uma solicitação de verdade pra escola aprovar.
const FLUXOS = {
  PCD: {
    pergunta: "Você é uma Pessoa Com Deficiência?",
    instrucao: "Envie um Certificado da Pessoa com Deficiência abaixo para que possamos habilitar seu tipo de conta.",
    erroLeitura: "Não foi possível ler o certificado.",
    campos: [
      ["Nome detectado", "João Silva"],
      ["CPF", "000.000.000-00"],
      ["Validade", "04/04/2026"],
    ],
    erroValidacao: "A atualização falhou. Seu certificado não é válido.",
  },
  Idoso: {
    pergunta: "Você tem 65 anos ou mais?",
    instrucao: "Envie um documento com foto (RG/CIN) abaixo para que possamos habilitar seu tipo de conta",
    erroLeitura: "Não foi possível ler seu documento.",
    campos: [
      ["Nome detectado", "João Silva"],
      ["CPF", "000.000.000-00"],
      ["Data de nascimento", "18/09/1954"],
      ["Idade", "72 anos"],
    ],
    erroValidacao: "A atualização falhou. Seu documento não é válido.",
  },
};

const STATUS_LABEL = {
  pendente: "Sua solicitação está com a escola, aguardando confirmação.",
  rejeitado: "Sua escola não confirmou a matrícula da última vez. Você pode tentar de novo.",
};

export default function TipoUsuarioScreen({ navigate }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    heading: { fontWeight: "800", fontSize: 16, color: C.headingSoft, marginBottom: 24 },
    grid: { flexDirection: "row", flexWrap: "wrap", gap: 14, marginBottom: 28 },
    tipoBtn: { width: "47%", paddingVertical: 22, borderRadius: 16, backgroundColor: C.amber, borderWidth: 2, borderColor: "transparent", alignItems: "center" },
    tipoBtnSelected: { borderColor: C.darkGreen, shadowColor: C.lightGreen, shadowOpacity: 1, shadowRadius: 0, elevation: 2 },
    tipoBtnText: { fontWeight: "800", fontSize: 18, color: C.darkGreen },
    modalTitleAmber: { color: C.amber, fontWeight: "900", fontSize: 18, marginBottom: 10, textAlign: "center" },
    modalTitleWhite: { color: C.onColor, fontWeight: "900", fontSize: 18, marginBottom: 12, textAlign: "center" },
    modalBody: { fontSize: 13, color: C.text, marginBottom: 16, textAlign: "center" },
    fileRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 16, justifyContent: "center" },
    fileHint: { fontSize: 12, color: C.textMuted, flexShrink: 1 },
    campoLine: { fontSize: 13, fontWeight: "700", color: C.text, marginBottom: 4 },
    pendingBanner: { backgroundColor: C.lightGray, borderRadius: 12, padding: 14, marginBottom: 20 },
    pendingBannerText: { color: C.text, fontSize: 13, textAlign: "center" },
  });

  const [selected, setSelected] = useState(null);
  const [stage, setStage] = useState(null); // confirmComum | upload | erroLeitura | valida | erroValidacao | erroApi | solicitarEstudante | pendenteEstudante | ok
  const [salvando, setSalvando] = useState(false);
  const [statusEstudante, setStatusEstudante] = useState(null);
  const [escolaNome, setEscolaNome] = useState("");
  const [escolaEmail, setEscolaEmail] = useState("");
  const [erroSolicitacao, setErroSolicitacao] = useState("");

  useEffect(() => {
    apiFetch("/me")
      .then((data) => setStatusEstudante(data.verificacao_estudante_status || null))
      .catch(() => {});
  }, []);

  const fluxo = selected && FLUXOS[selected];

  const handleConfirmar = () => {
    if (!selected) return;
    if (selected === "Comum") {
      setStage("confirmComum");
    } else if (selected === "Estudante") {
      setErroSolicitacao("");
      setStage(statusEstudante === "pendente" ? "pendenteEstudante" : "solicitarEstudante");
    } else {
      setStage("upload");
    }
  };

  const fechar = () => setStage(null);

  const salvarTipoUsuario = async (tipo) => {
    setSalvando(true);
    try {
      await apiFetch("/tipo-usuario", { method: "PUT", body: { tipo_usuario: tipo } });
      setStage(tipo === "comum" ? null : "ok");
    } catch (e) {
      setStage("erroApi");
    } finally {
      setSalvando(false);
    }
  };

  const enviarSolicitacaoEstudante = async () => {
    setErroSolicitacao("");
    if (!escolaNome.trim() || !escolaEmail.trim()) {
      setErroSolicitacao("Preencha o nome da escola e o email dela.");
      return;
    }
    setSalvando(true);
    try {
      await apiFetch("/tipo-usuario/solicitar-estudante", {
        method: "POST",
        body: { escola_nome: escolaNome.trim(), escola_email: escolaEmail.trim() },
      });
      setStatusEstudante("pendente");
      setStage("pendenteEstudante");
    } catch (e) {
      setErroSolicitacao(e.message);
    } finally {
      setSalvando(false);
    }
  };

  return (
    <View style={s.screen}>
      <TopBar title="Tipo de Usuário" onBack={() => navigate("conta")} />
      <View style={{ padding: 24 }}>
        <Text style={styles.heading}>Selecione a opção em{"\n"}que você se encaixa</Text>

        {statusEstudante && STATUS_LABEL[statusEstudante] && (
          <View style={styles.pendingBanner}>
            <Text style={styles.pendingBannerText}>{STATUS_LABEL[statusEstudante]}</Text>
          </View>
        )}

        <View style={styles.grid}>
          {TIPOS.map((t) => (
            <TouchableOpacity
              key={t}
              onPress={() => setSelected(t)}
              style={[styles.tipoBtn, selected === t && styles.tipoBtnSelected]}
            >
              <Text style={styles.tipoBtnText}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TouchableOpacity style={s.btnOrange} onPress={handleConfirmar}>
          <Text style={s.btnTextWhite}>Confirmar</Text>
        </TouchableOpacity>
      </View>

      <AppModal visible={stage === "confirmComum"} onClose={fechar}>
        <Text style={styles.modalTitleAmber}>Você tem certeza disso?</Text>
        <Text style={styles.modalBody}>
          Caso mude sua conta para "comum", você terá que refazer sua declaração
        </Text>
        <TouchableOpacity style={[s.btnOrange, { opacity: salvando ? 0.7 : 1 }]} disabled={salvando} onPress={() => salvarTipoUsuario("comum")}>
          <Text style={s.btnTextWhite}>{salvando ? "Salvando..." : "Confirmar"}</Text>
        </TouchableOpacity>
      </AppModal>

      <AppModal visible={stage === "upload" && !!fluxo} onClose={fechar}>
        {fluxo && (
          <>
            <Text style={styles.modalTitleAmber}>{fluxo.pergunta}</Text>
            <Text style={styles.modalBody}>{fluxo.instrucao}</Text>
            <View style={styles.fileRow}>
              <Text style={{ fontSize: 24 }}>📁</Text>
              <Text style={styles.fileHint}>Selecione o arquivo (jpg, jpeg, png e pdf)</Text>
            </View>
            <View style={{ gap: 8 }}>
              <TouchableOpacity style={s.btnOrange} onPress={() => setStage("erroLeitura")}>
                <Text style={s.btnTextWhite}>Enviar (erro)</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btnOrange, { backgroundColor: C.lightGreen }]} onPress={() => setStage("valida")}>
                <Text style={s.btnTextWhite}>Enviar (sucesso)</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </AppModal>

      <AppModal visible={stage === "erroLeitura" && !!fluxo} onClose={fechar} color={C.red}>
        <Text style={styles.modalTitleWhite}>{fluxo?.erroLeitura}</Text>
        <Text style={{ fontSize: 40, color: C.onColor, textAlign: "center" }}>✕</Text>
      </AppModal>

      <AppModal visible={stage === "valida" && !!fluxo} onClose={fechar}>
        {fluxo && (
          <>
            <Text style={styles.modalTitleAmber}>Valide suas informações</Text>
            <View style={{ marginBottom: 20 }}>
              {fluxo.campos.map(([label, valor]) => (
                <Text key={label} style={styles.campoLine}>
                  {label}: <Text style={{ fontWeight: "900" }}>{valor}</Text>
                </Text>
              ))}
            </View>
            <View style={{ gap: 8 }}>
              <TouchableOpacity style={[s.btnOrange, { opacity: salvando ? 0.7 : 1 }]} disabled={salvando} onPress={() => salvarTipoUsuario(selected.toLowerCase())}>
                <Text style={s.btnTextWhite}>{salvando ? "Salvando..." : "Confirmar"}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.btnRed} onPress={() => setStage("erroValidacao")}>
                <Text style={s.btnTextWhite}>Cancelar (simula erro)</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </AppModal>

      <AppModal visible={stage === "erroValidacao" && !!fluxo} onClose={fechar} color={C.red}>
        <Text style={styles.modalTitleWhite}>{fluxo?.erroValidacao}</Text>
        <Text style={{ fontSize: 40, color: C.onColor, textAlign: "center" }}>✕</Text>
      </AppModal>

      <AppModal visible={stage === "erroApi"} onClose={fechar} color={C.red}>
        <Text style={styles.modalTitleWhite}>Não foi possível atualizar seu tipo de usuário. Tente novamente.</Text>
        <Text style={{ fontSize: 40, color: C.onColor, textAlign: "center" }}>✕</Text>
      </AppModal>

      <AppModal visible={stage === "solicitarEstudante"} onClose={fechar}>
        <Text style={styles.modalTitleAmber}>Confirme sua matrícula</Text>
        <Text style={styles.modalBody}>
          Informe o nome e o email da sua escola. Vamos mandar um email pra ela confirmar sua matrícula — assim que responder, sua tarifa muda automaticamente.
        </Text>
        {erroSolicitacao ? (
          <View style={[s.errorBox, { marginHorizontal: 0 }]}>
            <Text style={s.errorText}>{erroSolicitacao}</Text>
          </View>
        ) : null}
        <View style={{ gap: 12, marginBottom: 16 }}>
          <View>
            <Text style={s.label}>Nome da escola</Text>
            <TextInput
              style={s.input}
              placeholder="Ex: Escola Estadual João Silva"
              placeholderTextColor={C.textMuted}
              value={escolaNome}
              onChangeText={setEscolaNome}
            />
          </View>
          <View>
            <Text style={s.label}>Email da escola</Text>
            <TextInput
              style={s.input}
              placeholder="secretaria@escola.com"
              placeholderTextColor={C.textMuted}
              keyboardType="email-address"
              autoCapitalize="none"
              value={escolaEmail}
              onChangeText={setEscolaEmail}
            />
          </View>
        </View>
        <TouchableOpacity style={[s.btnOrange, { opacity: salvando ? 0.7 : 1 }]} disabled={salvando} onPress={enviarSolicitacaoEstudante}>
          <Text style={s.btnTextWhite}>{salvando ? "Enviando..." : "Enviar solicitação"}</Text>
        </TouchableOpacity>
      </AppModal>

      <AppModal visible={stage === "pendenteEstudante"} onClose={fechar}>
        <Text style={styles.modalTitleAmber}>Solicitação enviada!</Text>
        <Text style={styles.modalBody}>
          Mandamos um email pra sua escola confirmar a matrícula. Assim que ela responder, você recebe um email com o resultado e, se aprovado, sua tarifa já muda sozinha.
        </Text>
        <TouchableOpacity style={s.btnOrange} onPress={fechar}>
          <Text style={s.btnTextWhite}>Entendi</Text>
        </TouchableOpacity>
      </AppModal>

      <AppModal visible={stage === "ok"} onClose={() => { setStage(null); navigate("conta"); }} color={C.lightGreen}>
        <Text style={styles.modalTitleWhite}>Seu Tipo de Usuário foi atualizado com sucesso.</Text>
        <Text style={{ fontSize: 40, color: C.onColor, textAlign: "center" }}>✓</Text>
      </AppModal>
    </View>
  );
}
