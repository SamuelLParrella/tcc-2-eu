import { useEffect, useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator, StyleSheet } from "react-native";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import TopBar from "../components/TopBar";
import AppModal from "../components/AppModal";
import Checkbox from "../components/Checkbox";

const MOTIVOS = [
  { key: "perdi", label: "Perdi meu cartão" },
  { key: "roubo", label: "Roubo ou furto" },
  { key: "tecnico", label: "Problemas técnicos" },
];

export default function StatusCartaoScreen({ navigate }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    statusCard: { borderRadius: 16, padding: 20, marginBottom: 24 },
    statusTitle: { color: C.onColor, fontWeight: "900", fontSize: 16, marginBottom: 8 },
    statusBody: { color: C.onColor, fontSize: 13 },
    modalTitle: { fontWeight: "900", fontSize: 16, color: C.text, textAlign: "center", marginBottom: 16 },
    motivoRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 12 },
    motivoLabel: { fontSize: 14, color: C.text },
    modalMsg: { fontWeight: "800", fontSize: 16, color: C.text, textAlign: "center" },
    errTitle: { color: C.red, fontWeight: "900", fontSize: 17, marginBottom: 10, textAlign: "center" },
    errBody: { fontWeight: "700", fontSize: 14, color: C.headingStrong, textAlign: "center" },
  });

  const [bloqueado, setBloqueado] = useState(false);
  const [carregando, setCarregando] = useState(true);
  const [enviando, setEnviando] = useState(false);
  const [modal, setModal] = useState(null);
  const [motivos, setMotivos] = useState({ perdi: false, roubo: false, tecnico: false, outro: false });
  const [outroText, setOutroText] = useState("");

  useEffect(() => {
    apiFetch("/me")
      .then((data) => setBloqueado(!!data.cartao_bloqueado))
      .catch(() => {})
      .finally(() => setCarregando(false));
  }, []);

  const fechar = () => setModal(null);

  const confirmarBloqueio = async () => {
    setEnviando(true);
    try {
      await apiFetch("/cartao/bloquear", { method: "POST" });
      setBloqueado(true);
      setModal("okBloquear");
    } catch (e) {
      setModal("errStatus");
    } finally {
      setEnviando(false);
    }
  };

  const confirmarDesbloqueio = async () => {
    setEnviando(true);
    try {
      await apiFetch("/cartao/desbloquear", { method: "POST" });
      setBloqueado(false);
      setModal("okDesbloquear");
    } catch (e) {
      setModal("errStatus");
    } finally {
      setEnviando(false);
    }
  };

  if (carregando) {
    return (
      <View style={s.screen}>
        <TopBar title="Status do cartão" onBack={() => navigate("conta")} />
        <ActivityIndicator size="large" color={C.lightGreen} style={{ marginTop: 40 }} />
      </View>
    );
  }

  return (
    <View style={s.screen}>
      <TopBar title="Status do cartão" onBack={() => navigate("conta")} />
      <View style={{ padding: 24 }}>
        <View style={[styles.statusCard, { backgroundColor: bloqueado ? C.red : C.brightGreen }]}>
          <Text style={styles.statusTitle}>{bloqueado ? "Seu cartão está bloqueado!" : "Seu cartão está ativo!"}</Text>
          <Text style={styles.statusBody}>
            {bloqueado
              ? "É necessária uma atualização de seus dados ou a validação de um novo cartão."
              : "Quando for necessária uma atualização nós te notificaremos."}
          </Text>
        </View>
        <TouchableOpacity
          style={bloqueado ? s.btnGreen : s.btnRed}
          onPress={() => setModal(bloqueado ? "desbloquear" : "bloquear")}
        >
          <Text style={s.btnTextWhite}>{bloqueado ? "Deseja desbloquear seu cartão?" : "Deseja bloquear seu cartão?"}</Text>
        </TouchableOpacity>
      </View>

      <AppModal visible={modal === "bloquear"} onClose={fechar}>
        <Text style={styles.modalTitle}>Nos explique o motivo!</Text>
        {MOTIVOS.map((item) => (
          <TouchableOpacity
            key={item.key}
            style={styles.motivoRow}
            onPress={() => setMotivos({ ...motivos, [item.key]: !motivos[item.key] })}
          >
            <Checkbox checked={motivos[item.key]} onToggle={() => setMotivos({ ...motivos, [item.key]: !motivos[item.key] })} />
            <Text style={styles.motivoLabel}>{item.label}</Text>
          </TouchableOpacity>
        ))}
        <View style={styles.motivoRow}>
          <Checkbox checked={motivos.outro} onToggle={() => setMotivos({ ...motivos, outro: !motivos.outro })} />
          <View style={{ flex: 1 }}>
            <Text style={styles.motivoLabel}>Outro:</Text>
            <TextInput
              value={outroText}
              onChangeText={setOutroText}
              placeholder="Nos diga qual..."
              placeholderTextColor={C.textMuted}
              style={[s.input, { marginTop: 6, paddingVertical: 8, fontSize: 13 }]}
            />
          </View>
        </View>
        <TouchableOpacity style={[s.btnRed, { marginTop: 16, opacity: enviando ? 0.7 : 1 }]} onPress={confirmarBloqueio} disabled={enviando}>
          <Text style={s.btnTextWhite}>{enviando ? "Bloqueando..." : "Bloquear cartão"}</Text>
        </TouchableOpacity>
      </AppModal>

      <AppModal visible={modal === "okBloquear"} onClose={() => { setModal(null); setBloqueado(true); }}>
        <Text style={styles.modalMsg}>
          Cartão bloqueado com sucesso! Em breve enviaremos um relatório em seu email.
        </Text>
      </AppModal>

      <AppModal visible={modal === "desbloquear"} onClose={fechar}>
        <Text style={[styles.modalMsg, { marginBottom: 20 }]}>Tem certeza que deseja desbloquear o cartão?</Text>
        <TouchableOpacity style={[s.btnGreen, { opacity: enviando ? 0.7 : 1 }]} onPress={confirmarDesbloqueio} disabled={enviando}>
          <Text style={s.btnTextWhite}>{enviando ? "Desbloqueando..." : "Confirmar"}</Text>
        </TouchableOpacity>
      </AppModal>

      <AppModal visible={modal === "okDesbloquear"} onClose={() => { setModal(null); setBloqueado(false); }}>
        <Text style={styles.modalMsg}>
          Cartão desbloqueado com sucesso! Em breve enviaremos um relatório em seu email.
        </Text>
      </AppModal>

      <AppModal visible={modal === "errStatus"} onClose={fechar}>
        <Text style={styles.errTitle}>Algo falhou! :(</Text>
        <Text style={styles.errBody}>Não foi possível mudar o Status do seu Cartão. Entre em contato com a empresa.</Text>
      </AppModal>
    </View>
  );
}
