import { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import { apiFetch, clearToken } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import TopBar from "../components/TopBar";
import AppModal from "../components/AppModal";

export default function AlterarSenhaScreen({ navigate, onLogout }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    title: { fontWeight: "800", fontSize: 16, color: C.headingSoft, marginBottom: 24 },
    okText: { color: C.headingSoft, fontWeight: "800", fontSize: 15, marginBottom: 16, textAlign: "center" },
  });

  const [senhaAtual, setSenhaAtual] = useState("");
  const [senhaNova, setSenhaNova] = useState("");
  const [senhaConfirmar, setSenhaConfirmar] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);
  const [modal, setModal] = useState(null);

  const handleConfirmar = async () => {
    setErro("");
    if (!senhaAtual || !senhaNova) {
      setErro("Preencha a senha atual e a nova senha.");
      return;
    }
    if (senhaNova.length < 6) {
      setErro("A nova senha deve ter pelo menos 6 caracteres.");
      return;
    }
    if (senhaNova !== senhaConfirmar) {
      setErro("As senhas não coincidem.");
      return;
    }
    setLoading(true);
    try {
      await apiFetch("/senha", { method: "PUT", body: { senha_atual: senhaAtual, senha_nova: senhaNova } });
      setModal("ok");
    } catch (e) {
      setErro(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleFazerLoginNovamente = async () => {
    await clearToken();
    onLogout();
  };

  return (
    <View style={s.screen}>
      <TopBar title="Alterar Senha" onBack={() => navigate("conta")} />
      <View style={{ padding: 28, paddingTop: 32 }}>
        <Text style={styles.title}>Altere sua senha</Text>

        {erro ? (
          <View style={s.errorBox}>
            <Text style={s.errorText}>{erro}</Text>
          </View>
        ) : null}

        <View style={{ gap: 16 }}>
          <View>
            <Text style={s.label}>Senha atual</Text>
            <TextInput
              style={s.input}
              placeholder="Sua senha atual"
              placeholderTextColor={C.textMuted}
              secureTextEntry
              value={senhaAtual}
              onChangeText={setSenhaAtual}
            />
          </View>
          <View>
            <Text style={s.label}>Nova senha</Text>
            <TextInput
              style={s.input}
              placeholder="Nova senha"
              placeholderTextColor={C.textMuted}
              secureTextEntry
              value={senhaNova}
              onChangeText={setSenhaNova}
            />
          </View>
          <View>
            <Text style={s.label}>Confirmar nova senha</Text>
            <TextInput
              style={s.input}
              placeholder="Confirmar nova senha"
              placeholderTextColor={C.textMuted}
              secureTextEntry
              value={senhaConfirmar}
              onChangeText={setSenhaConfirmar}
            />
          </View>
        </View>

        <TouchableOpacity style={[s.btnOrange, { marginTop: 24, opacity: loading ? 0.7 : 1 }]} onPress={handleConfirmar} disabled={loading}>
          <Text style={s.btnTextWhite}>{loading ? "Salvando..." : "Confirmar"}</Text>
        </TouchableOpacity>
      </View>

      <AppModal visible={modal === "ok"} onClose={() => setModal(null)}>
        <Text style={styles.okText}>Senha alterada com sucesso!{"\n"}Faça o login novamente no app.</Text>
        <TouchableOpacity style={s.btnOrange} onPress={handleFazerLoginNovamente}>
          <Text style={s.btnTextWhite}>Fazer login</Text>
        </TouchableOpacity>
      </AppModal>
    </View>
  );
}
