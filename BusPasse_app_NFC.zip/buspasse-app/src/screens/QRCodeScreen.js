import { useEffect, useRef, useState } from "react";
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator, Alert } from "react-native";
import QRCode from "react-native-qrcode-svg";
import * as Clipboard from "expo-clipboard";
import { apiFetch } from "../api/client";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import BottomNav from "../components/BottomNav";
import { formatMoney } from "../utils/format";

export default function QRCodeScreen({ navigate, recargaValor }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    header: { backgroundColor: C.darkGreen, paddingTop: 22, paddingBottom: 18, paddingHorizontal: 20 },
    headerTitle: { color: C.lightGreen, fontWeight: "900", fontSize: 22, textAlign: "center" },
    content: { padding: 24, alignItems: "center" },
    title: { fontWeight: "900", fontSize: 22, color: C.lightGreen, marginBottom: 4 },
    subtitle: { fontSize: 14, color: C.text, marginBottom: 24 },
    errorText: { color: C.red, fontSize: 14, textAlign: "center", marginVertical: 40 },
    qrBox: { width: 216, height: 216, borderWidth: 2, borderColor: C.border, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: C.onColor, marginBottom: 20 },
    copyHint: { fontSize: 13, color: C.textMuted, marginBottom: 12 },
    codeBox: { backgroundColor: C.darkGreen, borderRadius: 12, padding: 14, width: "100%" },
    codeText: { color: "rgba(255,255,255,0.8)", fontSize: 11 },
    copyBtn: { marginTop: 10, paddingVertical: 10, borderRadius: 50, backgroundColor: C.onColor, alignItems: "center" },
    copyBtnText: { fontWeight: "700", fontSize: 14, color: C.darkGreen },
    actions: { marginTop: 20, gap: 10, width: "100%" },
  });

  const [recarga, setRecarga] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const pollRef = useRef(null);

  useEffect(() => {
    let ativo = true;
    async function criarRecarga() {
      setLoading(true);
      setError("");
      try {
        const data = await apiFetch("/recarga", { method: "POST", body: { valor: recargaValor } });
        if (ativo) setRecarga(data);
      } catch (e) {
        if (ativo) setError(e.message);
      } finally {
        if (ativo) setLoading(false);
      }
    }
    if (recargaValor > 0) {
      criarRecarga();
    } else {
      setError("Valor de recarga inválido.");
      setLoading(false);
    }
    return () => { ativo = false; };
  }, [recargaValor]);

  useEffect(() => {
    if (!recarga?.id) return undefined;

    // Consulta periodicamente o status da recarga — arquitetura pronta para o
    // dia em que um PSP real confirmar o Pix via webhook no backend.
    pollRef.current = setInterval(async () => {
      try {
        const status = await apiFetch(`/recarga/${recarga.id}`);
        if (status.status === "pago") {
          clearInterval(pollRef.current);
          avisarSucesso();
        }
      } catch (e) {
        // ignora falhas pontuais de polling
      }
    }, 4000);

    return () => clearInterval(pollRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- só deve reiniciar o polling quando o ID da recarga mudar, não a cada render
  }, [recarga?.id]);

  const avisarSucesso = () => {
    Alert.alert("Pagamento confirmado!", "Sua recarga foi concluída com sucesso.", [
      { text: "OK", onPress: () => navigate("saldo") },
    ]);
  };

  const handleCopiar = async () => {
    if (!recarga?.pix_copia_cola) return;
    await Clipboard.setStringAsync(recarga.pix_copia_cola);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleJaPaguei = async () => {
    if (!recarga?.id) return;
    setConfirming(true);
    try {
      await apiFetch(`/recarga/${recarga.id}/confirmar`, { method: "POST" });
      if (pollRef.current) clearInterval(pollRef.current);
      avisarSucesso();
    } catch (e) {
      Alert.alert("Não foi possível confirmar", e.message);
    } finally {
      setConfirming(false);
    }
  };

  return (
    <View style={s.screen}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Recarga</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.title}>Pague com Pix</Text>
        <Text style={styles.subtitle}>
          Valor: <Text style={{ color: C.lightGreen, fontWeight: "800" }}>{formatMoney(recargaValor || 0)}</Text>
        </Text>

        {loading ? (
          <ActivityIndicator size="large" color={C.lightGreen} style={{ marginVertical: 40 }} />
        ) : error ? (
          <Text style={styles.errorText}>{error}</Text>
        ) : (
          <>
            <View style={styles.qrBox}>
              <QRCode value={recarga.pix_copia_cola} size={196} />
            </View>

            <Text style={styles.copyHint}>ou copie o código</Text>
            <View style={styles.codeBox}>
              <Text style={styles.codeText} numberOfLines={3} ellipsizeMode="middle">
                {recarga.pix_copia_cola}
              </Text>
              <TouchableOpacity style={styles.copyBtn} onPress={handleCopiar}>
                <Text style={styles.copyBtnText}>{copied ? "Copiado! ✓" : "Copiar"}</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.actions}>
              <TouchableOpacity style={[s.btnGreen, { opacity: confirming ? 0.7 : 1 }]} onPress={handleJaPaguei} disabled={confirming}>
                <Text style={s.btnTextWhite}>{confirming ? "Confirmando..." : "Já paguei"}</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.btnOutline} onPress={() => navigate("recarga")}>
                <Text style={s.btnTextGreen}>Cancelar</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
      <BottomNav active="recarga" navigate={navigate} />
    </View>
  );
}
