import { View, Text, ScrollView, StyleSheet } from "react-native";
import { useTheme } from "../theme/ThemeContext";
import { getSharedStyles } from "../theme/styles";
import TopBar from "../components/TopBar";
import { formatMoney, formatDateLong, formatTime } from "../utils/format";

export default function TxDetailScreen({ navigate, tx, user }) {
  const { colors: C } = useTheme();
  const s = getSharedStyles(C);
  const styles = StyleSheet.create({
    content: { padding: 24, paddingVertical: 32 },
    icon: { width: 64, height: 64, borderRadius: 16, alignItems: "center", justifyContent: "center", marginBottom: 16 },
    iconDebit: { backgroundColor: C.darkGreen },
    iconCredit: { borderWidth: 2, borderColor: C.lightGreen },
    value: { fontSize: 32, fontWeight: "900", marginBottom: 32 },
    cardTitle: { fontWeight: "800", fontSize: 16, color: C.headingStrong, marginBottom: 16 },
    infoRow: { flexDirection: "row", justifyContent: "space-between", marginBottom: 12, gap: 8 },
    infoLabel: { color: C.headingSoft, fontWeight: "700", fontSize: 13 },
    infoValue: { fontWeight: "700", fontSize: 13, color: C.text, maxWidth: "60%", textAlign: "right" },
  });

  function InfoRow({ label, value }) {
    return (
      <View style={styles.infoRow}>
        <Text style={styles.infoLabel}>{label}</Text>
        <Text style={styles.infoValue}>{value}</Text>
      </View>
    );
  }

  if (!tx) return null;
  const isDebit = tx.tipo === "debito";

  return (
    <View style={s.screen}>
      <TopBar title={tx.descricao} onBack={() => navigate("saldo")} />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={[styles.icon, isDebit ? styles.iconDebit : styles.iconCredit, { alignSelf: "center" }]}>
          <Text style={{ fontSize: 28, fontWeight: "900", color: isDebit ? C.amber : C.lightGreen }}>
            {isDebit ? "↓" : "↑"}
          </Text>
        </View>
        <Text style={[styles.value, { color: isDebit ? C.amber : C.headingStrong, alignSelf: "center" }]}>
          {isDebit ? "-" : "+"}
          {formatMoney(tx.valor)}
        </Text>

        <View style={s.card}>
          <Text style={styles.cardTitle}>Sobre a transação</Text>
          <InfoRow label="Data" value={formatDateLong(tx.data)} />
          <InfoRow label="Horário" value={formatTime(tx.data)} />
          <InfoRow label="Tipo" value={isDebit ? "Uso de passagem" : "Recarga via Pix"} />
          <InfoRow label="Nº da transação" value={`#${tx.id}`} />
        </View>

        {!isDebit && (
          <View style={[s.card, { marginTop: 16 }]}>
            <Text style={styles.cardTitle}>Pagador</Text>
            <InfoRow label="Nome" value={user?.nome || "Usuário"} />
            <InfoRow label="Método" value="Pix" />
          </View>
        )}
      </ScrollView>
    </View>
  );
}
