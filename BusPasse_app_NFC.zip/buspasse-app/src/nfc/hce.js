import { Linking, Platform } from "react-native";
import { requireOptionalNativeModule } from "expo";

// Módulo nativo (Android) que faz o celular responder como cartão para o leitor
// do ônibus: modules/buspass-hce. Ele só existe no aplicativo instalado (APK).
// No Expo Go e no Snack `requireOptionalNativeModule` devolve null, e a tela
// "Pagar com o celular" apenas avisa que o recurso não está disponível — o
// restante do app continua funcionando normalmente.
const Native = Platform.OS === "android" ? requireOptionalNativeModule("BuspassHce") : null;

export const nfcDisponivelNoApp = Native != null;

export async function celularSuportaHce() {
  if (!Native) return false;
  try {
    return await Native.isSupportedAsync();
  } catch (e) {
    return false;
  }
}

export async function nfcLigado() {
  if (!Native) return false;
  try {
    return await Native.isNfcEnabledAsync();
  } catch (e) {
    return false;
  }
}

// Deixa o token pronto para o celular entregar ao leitor até `validadeSegundos`.
export function armarToken(token, validadeSegundos) {
  return Native.armAsync(token, validadeSegundos);
}

export async function desarmarToken() {
  if (!Native) return;
  try {
    await Native.disarmAsync();
  } catch (e) {
    // sem token armado não há o que desfazer
  }
}

export function abrirConfiguracoesNfc() {
  return Linking.sendIntent("android.settings.NFC_SETTINGS").catch(() => Linking.openSettings());
}
