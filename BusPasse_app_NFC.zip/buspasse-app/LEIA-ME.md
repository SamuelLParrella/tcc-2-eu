# Pagamento por aproximação com o celular (NFC)

O celular Android com o app BusPasse funciona como o cartão físico: o passageiro
encosta no leitor do ônibus (ESP32 + RC522), a API valida e debita a passagem, e o
leitor acende o LED verde (ou vermelho).

## Como funciona

```
App ──POST /nfc/token──────────────► API    gera token (16 hex, vale 120 s, uso único)
App ──armAsync(token)──► módulo Android     guarda o token "armado" no celular
Celular ◄──── NFC (ISO 14443-4) ────► Leitor
              RATS
              SELECT AID F0 42 55 53 50 41 53 53 ("F0"+"BUSPASS")
              resposta: "BP1:" + token + 90 00
              DESELECT
Leitor ──POST /nfc/validar─────────► API    confere token, validade, bloqueio, saldo; debita
App ──GET /nfc/status (a cada 2 s)─► API    "ok" ou o motivo da recusa
```

Por que não identificar o celular pelo UID, como no cartão físico? Porque o Android,
ao emular um cartão (HCE), usa um UID aleatório que muda a cada aproximação. Por isso
o celular entrega um **token de uso único** e quem decide é a API. Se o token vazar,
ele só serve uma vez e vence em 2 minutos.

O cartão físico continua exatamente como era: o leitor manda o UID para
`POST /cartao/verificar`, que só confere se o cartão está cadastrado.

## Arquivos

| Onde | O que |
|---|---|
| `main.py` | `POST /nfc/token`, `GET /nfc/status`, `POST /nfc/cancelar` (app, com login) e `POST /nfc/validar` (leitor) |
| `schema.sql` | colunas `nfc_token`, `nfc_token_expira_em`, `nfc_resultado` |
| `app/modules/buspass-hce/` | módulo Android (Kotlin): serviço que responde ao leitor + ponte para o JavaScript |
| `app/src/nfc/hce.js` | wrapper em JavaScript (devolve "indisponível" no Expo Go/Snack em vez de quebrar) |
| `app/src/screens/NfcScreen.js` | tela "Pagar com o celular" |
| `firmware/buspasse_validador/` | sketch do ESP32 (cartão por UID + celular por NFC) |

## Passo a passo

1. **Banco de dados** — rodar uma vez:
   ```sql
   ALTER TABLE usuarios
   ADD COLUMN nfc_token           VARCHAR(32) NULL,
   ADD COLUMN nfc_token_expira_em DATETIME    NULL,
   ADD COLUMN nfc_resultado       VARCHAR(30) NULL;

   CREATE INDEX idx_usuarios_nfc_token ON usuarios(nfc_token);
   ```
2. **API** — substituir o `main.py` no GitHub (o Render faz o deploy sozinho).
3. **Leitor** — abrir `buspasse_validador.ino` no Arduino IDE, conferir `ssid` e
   `password` no topo e gravar no ESP32.
4. **App** — o NFC não funciona no Snack nem no Expo Go (precisa de código nativo),
   então é preciso gerar o APK: dar dois cliques em `gerar-apk.bat` (Windows) ou rodar
   `./gerar-apk.sh` (Mac/Linux) dentro da pasta `app`. Precisa de Node.js 20+ e de uma
   conta gratuita no Expo. No fim sai um link: abrir no celular Android e instalar o APK.
5. **Teste** — no app: Saldo → "Pagar com o celular (NFC)" → "Ativar". Com a tela ligada
   e desbloqueada, encostar a parte de trás do celular no RC522 (1 a 3 cm, parado).

## Se não funcionar (Monitor Serial do Arduino IDE, 115200)

| O que aparece | Causa provável |
|---|---|
| Nada ao encostar | o RC522 não detectou o celular: NFC desligado, alinhamento (a antena fica na parte de cima/meio das costas), distância; tentar descomentar `PCD_SetAntennaGain` no `setup()` |
| `RATS falhou` | o celular respondeu à seleção mas não ao RATS: afastar e encostar de novo, sem mexer |
| `SELECT do BusPasse falhou` | o celular não tem o app instalado (APK) ou o AID não confere |
| `Tamanho de resposta inesperado` | o celular respondeu `69 85`: não há token armado — tocar em "Ativar" antes de encostar |
| `HTTP: 200` e `"motivo":"saldo_insuficiente"` etc. | funcionou; a API recusou (saldo, cartão bloqueado, código vencido) |
| `Erro HTTP` ou código diferente de 200 | Wi-Fi ou API fora do ar (no plano grátis do Render a primeira chamada pode demorar) |

O RC522 é um leitor barato e fraco para falar com celulares. Se mesmo com tudo certo ele
falhar em vários aparelhos, o caminho é trocar o módulo por um **PN532** (mesma ligação
SPI/I2C), que trata o protocolo ISO-DEP no próprio chip.

## Limitações

- Só Android com NFC. O iPhone não permite emular cartão para apps de terceiros no Brasil.
- O leitor funciona com a tela do celular ligada e desbloqueada.
- A confirmação do Pix continua simulada (chave estática, sem PSP).
