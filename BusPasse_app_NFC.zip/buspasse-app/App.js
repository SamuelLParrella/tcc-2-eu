import { useEffect, useState } from "react";
import { View, ActivityIndicator, StatusBar } from "react-native";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { getToken, clearToken, apiFetch } from "./src/api/client";
import { ThemeProvider, useTheme } from "./src/theme/ThemeContext";

import AuthScreen from "./src/screens/AuthScreen";
import SaldoScreen from "./src/screens/SaldoScreen";
import TxDetailScreen from "./src/screens/TxDetailScreen";
import RecargaScreen from "./src/screens/RecargaScreen";
import QRCodeScreen from "./src/screens/QRCodeScreen";
import ContaScreen from "./src/screens/ContaScreen";
import TipoUsuarioScreen from "./src/screens/TipoUsuarioScreen";
import StatusCartaoScreen from "./src/screens/StatusCartaoScreen";
import AlterarSenhaScreen from "./src/screens/AlterarSenhaScreen";
import AlterarInfoScreen from "./src/screens/AlterarInfoScreen";
import AdminScreen from "./src/screens/AdminScreen";
import NfcScreen from "./src/screens/NfcScreen";

function AppContent() {
  const { colors: C, isDark } = useTheme();
  const [bootstrapping, setBootstrapping] = useState(true);
  const [screen, setScreen] = useState("auth");
  const [selectedTx, setSelectedTx] = useState(null);
  const [recargaValor, setRecargaValor] = useState(0);
  const [currentUser, setCurrentUser] = useState(null); // { nome, id, token }

  // Mantém o usuário logado entre aberturas do app, validando o token salvo.
  useEffect(() => {
    (async () => {
      const token = await getToken();
      if (!token) { setBootstrapping(false); return; }
      try {
        const me = await apiFetch("/me", { token });
        setCurrentUser({ nome: me.nome, id: me.id, token });
        setScreen("saldo");
      } catch (e) {
        await clearToken();
      } finally {
        setBootstrapping(false);
      }
    })();
  }, []);

  const navigate = (next) => setScreen(next);

  const onLogin = (user) => {
    setCurrentUser(user);
    setScreen("saldo");
  };

  const onLogout = async () => {
    await clearToken();
    setCurrentUser(null);
    setScreen("auth");
  };

  const onPerfilAtualizado = (dados) => {
    setCurrentUser((u) => (u ? { ...u, nome: dados.nome } : u));
  };

  if (bootstrapping) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: C.offWhite }}>
        <ActivityIndicator size="large" color={C.lightGreen} />
      </View>
    );
  }

  const screens = {
    auth: <AuthScreen onLogin={onLogin} />,
    saldo: <SaldoScreen navigate={navigate} setSelectedTx={setSelectedTx} user={currentUser} />,
    txDetail: <TxDetailScreen navigate={navigate} tx={selectedTx} user={currentUser} />,
    recarga: <RecargaScreen navigate={navigate} setRecargaValor={setRecargaValor} />,
    qrcode: <QRCodeScreen navigate={navigate} recargaValor={recargaValor} />,
    conta: <ContaScreen navigate={navigate} user={currentUser} onLogout={onLogout} />,
    tipoUsuario: <TipoUsuarioScreen navigate={navigate} />,
    statusCartao: <StatusCartaoScreen navigate={navigate} />,
    alterarSenha: <AlterarSenhaScreen navigate={navigate} onLogout={onLogout} />,
    alterarInfo: <AlterarInfoScreen navigate={navigate} onPerfilAtualizado={onPerfilAtualizado} />,
    admin: <AdminScreen navigate={navigate} />,
    nfc: <NfcScreen navigate={navigate} />,
  };

  return (
    <>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <SafeAreaView style={{ flex: 1, backgroundColor: C.offWhite }} edges={["top", "left", "right"]}>
        {screens[screen] || screens.auth}
      </SafeAreaView>
    </>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AppContent />
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
