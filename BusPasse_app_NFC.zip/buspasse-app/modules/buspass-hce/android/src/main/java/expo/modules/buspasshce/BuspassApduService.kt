package expo.modules.buspasshce

import android.content.Context
import android.nfc.cardemulation.HostApduService
import android.os.Bundle

/**
 * Faz o celular responder como um "cartão" para o leitor do ônibus.
 *
 * O leitor (ESP32 + RC522) manda um comando SELECT com o AID do BusPasse e este
 * serviço responde com o token de uso único que o app deixou armado antes
 * (BuspassHceModule.armAsync): "BP1:" + 16 caracteres hexadecimais + 90 00.
 * Sem token armado (ou com token vencido) responde 69 85 e o leitor mostra
 * "inválido". Quem decide se a passagem é paga é a API, não o celular.
 */
class BuspassApduService : HostApduService() {

  override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
    if (commandApdu == null || !ehSelectDoBuspass(commandApdu)) {
      return SW_INS_NAO_SUPORTADO
    }

    val prefs = applicationContext.getSharedPreferences(PREFS_NOME, Context.MODE_PRIVATE)
    val token = prefs.getString(PREFS_TOKEN, null)
    val expiraEm = prefs.getLong(PREFS_EXPIRA_EM, 0L)

    if (token.isNullOrEmpty() || System.currentTimeMillis() > expiraEm) {
      return SW_CONDICOES_NAO_SATISFEITAS
    }

    return (PREFIXO_RESPOSTA + token).toByteArray(Charsets.US_ASCII) + SW_OK
  }

  override fun onDeactivated(reason: Int) {
    // Nada a limpar: o serviço não guarda estado entre aproximações.
  }

  // Formato do comando: 00 A4 04 00 <tamanho do AID> <AID> [Le]
  private fun ehSelectDoBuspass(cmd: ByteArray): Boolean {
    if (cmd.size < 5 + AID_BUSPASS.size) return false
    if (cmd[0] != 0x00.toByte() || cmd[1] != 0xA4.toByte() || cmd[2] != 0x04.toByte()) return false
    if (cmd[4].toInt() != AID_BUSPASS.size) return false
    return cmd.copyOfRange(5, 5 + AID_BUSPASS.size).contentEquals(AID_BUSPASS)
  }

  companion object {
    // Arquivo de preferências compartilhado com BuspassHceModule.
    const val PREFS_NOME = "buspass_hce"
    const val PREFS_TOKEN = "token"
    const val PREFS_EXPIRA_EM = "expira_em"

    private const val PREFIXO_RESPOSTA = "BP1:"

    // F0 + "BUSPASS" em ASCII. Igual ao <aid-filter> de res/xml/buspass_apdu_service.xml
    // e ao AID_BUSPASS do firmware do leitor.
    private val AID_BUSPASS = byteArrayOf(0xF0.toByte(), 0x42, 0x55, 0x53, 0x50, 0x41, 0x53, 0x53)

    private val SW_OK = byteArrayOf(0x90.toByte(), 0x00)
    private val SW_CONDICOES_NAO_SATISFEITAS = byteArrayOf(0x69, 0x85.toByte())
    private val SW_INS_NAO_SUPORTADO = byteArrayOf(0x6D, 0x00)
  }
}
