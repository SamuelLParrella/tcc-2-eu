package expo.modules.buspasshce

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.nfc.NfcAdapter
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

/**
 * Ponte entre o JavaScript do app e o serviço BuspassApduService.
 *
 * O app não "liga" o NFC: ele só deixa um token armado (com validade) nas
 * preferências. Quando o leitor do ônibus encosta, o Android chama o serviço,
 * que lê esse token e responde ao leitor.
 */
class BuspassHceModule : Module() {
  private val context: Context
    get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()

  private val prefs: SharedPreferences
    get() = context.getSharedPreferences(BuspassApduService.PREFS_NOME, Context.MODE_PRIVATE)

  override fun definition() = ModuleDefinition {
    Name("BuspassHce")

    // O celular sabe emular cartão (HCE)?
    AsyncFunction<Boolean>("isSupportedAsync") {
      context.packageManager.hasSystemFeature(PackageManager.FEATURE_NFC_HOST_CARD_EMULATION)
    }

    // O NFC está ligado nas configurações do celular?
    AsyncFunction<Boolean>("isNfcEnabledAsync") {
      NfcAdapter.getDefaultAdapter(context)?.isEnabled ?: false
    }

    // Deixa o token armado: o serviço passa a entregá-lo ao leitor até vencer.
    AsyncFunction("armAsync") { token: String, validadeSegundos: Int ->
      val expiraEm = System.currentTimeMillis() + validadeSegundos * 1000L
      prefs.edit()
        .putString(BuspassApduService.PREFS_TOKEN, token)
        .putLong(BuspassApduService.PREFS_EXPIRA_EM, expiraEm)
        .apply()
      return@AsyncFunction true
    }

    // Apaga o token: a partir daqui o celular não entrega mais nada ao leitor.
    AsyncFunction<Boolean>("disarmAsync") {
      prefs.edit().clear().apply()
      true
    }
  }
}
