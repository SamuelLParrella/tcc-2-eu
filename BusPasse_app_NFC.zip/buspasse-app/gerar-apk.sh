#!/bin/bash
# BusPasse: gera o APK do app (Android) usando o EAS Build, na nuvem do Expo.
set -e
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Falta instalar o Node.js (versão 20 ou mais nova): https://nodejs.org"
  exit 1
fi

# Esta pasta não é um repositório git: pede ao EAS para não exigir git.
export EAS_NO_VCS=1

echo "[1/3] Instalando as dependências (demora alguns minutos na primeira vez)..."
npm install

echo
echo "[2/3] Login no Expo (conta gratuita: https://expo.dev/signup)..."
if ! npx --yes eas-cli@latest whoami >/dev/null 2>&1; then
  npx --yes eas-cli@latest login
fi

echo
echo "[3/3] Gerando o APK na nuvem do Expo (10 a 30 minutos)."
echo "Se perguntar se deve criar o projeto ou gerar um Keystore, responda Y."
npx --yes eas-cli@latest build --platform android --profile preview

echo
echo "Pronto! Abra o link do build no celular Android, baixe o APK e instale."
